import { BrowserRouter, Route, Routes } from "react-router-dom";
import { DefaultProviders } from "./components/providers/default.tsx";
import { Authenticated, Unauthenticated, AuthLoading } from "convex/react";
import AuthCallback from "./pages/auth/Callback.tsx";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import DashboardLayout from "./pages/dashboard/_components/dashboard-layout.tsx";
import DashboardHome from "./pages/dashboard/page.tsx";
import ContactsPage from "./pages/dashboard/contacts/page.tsx";
import CampaignsPage from "./pages/dashboard/campaigns/page.tsx";
import AccountsPage from "./pages/dashboard/accounts/page.tsx";
import AiCopyPage from "./pages/dashboard/ai-copy/page.tsx";
import AnalyticsPage from "./pages/dashboard/analytics/page.tsx";
import TemplatesPage from "./pages/dashboard/templates/page.tsx";
import SettingsPage from "./pages/dashboard/settings/page.tsx";
import InboxPage from "./pages/dashboard/inbox/page.tsx";
import { SignInButton } from "./components/ui/signin.tsx";
import { Skeleton } from "./components/ui/skeleton.tsx";

function AuthGate({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Authenticated>{children}</Authenticated>
      <Unauthenticated>
        <div className="min-h-screen flex items-center justify-center bg-background">
          <div className="text-center space-y-6 max-w-sm">
            <h1 className="text-2xl font-bold">请先登录</h1>
            <p className="text-muted-foreground text-sm">
              登录后即可访问 TK-G 营销系统
            </p>
            <SignInButton />
          </div>
        </div>
      </Unauthenticated>
      <AuthLoading>
        <div className="min-h-screen flex items-center justify-center bg-background">
          <Skeleton className="h-12 w-48" />
        </div>
      </AuthLoading>
    </>
  );
}

import { useServiceWorker } from "@/hooks/use-service-worker.ts";

export default function App() {
  useServiceWorker();
  return (
    <DefaultProviders>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/auth/callback" element={<AuthCallback />} />

          {/* Dashboard - requires auth */}
          <Route
            element={
              <AuthGate>
                <DashboardLayout />
              </AuthGate>
            }
          >
            <Route path="/dashboard" element={<DashboardHome />} />
            <Route path="/dashboard/contacts" element={<ContactsPage />} />
            <Route path="/dashboard/campaigns" element={<CampaignsPage />} />
            <Route path="/dashboard/accounts" element={<AccountsPage />} />
            <Route path="/dashboard/ai-copy" element={<AiCopyPage />} />
            <Route path="/dashboard/analytics" element={<AnalyticsPage />} />
            <Route path="/dashboard/templates" element={<TemplatesPage />} />
            <Route path="/dashboard/settings" element={<SettingsPage />} />
            <Route path="/dashboard/inbox" element={<InboxPage />} />
          </Route>

          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </DefaultProviders>
  );
}
