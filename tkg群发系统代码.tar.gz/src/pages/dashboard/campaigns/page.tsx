import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import {
  Plus, Send, Pause, Play, Trash2, Clock, Copy,
  ChevronRight, CalendarClock, X, CheckCircle2,
  Eye, MessageSquare, Users, BookOpen, Search,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from "@/components/ui/sheet.tsx";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select.tsx";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import {
  Empty, EmptyHeader, EmptyMedia, EmptyTitle,
  EmptyDescription, EmptyContent,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import type { Id, Doc } from "@/convex/_generated/dataModel.d.ts";

type Campaign = Doc<"campaigns">;

const STATUS_MAP: Record<string, { label: string; dot: string; badge: string }> = {
  draft:     { label: "草稿",   dot: "bg-muted-foreground",  badge: "bg-muted text-muted-foreground" },
  scheduled: { label: "已排程", dot: "bg-blue-400",          badge: "bg-blue-400/10 text-blue-400" },
  running:   { label: "发送中", dot: "bg-primary animate-pulse", badge: "bg-primary/10 text-primary" },
  paused:    { label: "已暂停", dot: "bg-yellow-400",        badge: "bg-yellow-400/10 text-yellow-400" },
  completed: { label: "已完成", dot: "bg-green-400",         badge: "bg-green-400/10 text-green-400" },
  failed:    { label: "失败",   dot: "bg-destructive",       badge: "bg-destructive/10 text-destructive" },
};

function ProgressBar({ value, max, color }: { value: number; max: number; color: string }) {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  return (
    <div className="w-full bg-muted rounded-full h-1">
      <div className={`h-1 rounded-full transition-all ${color}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

function CountdownBadge({ scheduledAt }: { scheduledAt: string }) {
  const diff = new Date(scheduledAt).getTime() - Date.now();
  if (diff <= 0) return <span className="text-[10px] text-yellow-400">待触发</span>;
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  return (
    <span className="text-[10px] text-blue-400 flex items-center gap-0.5">
      <CalendarClock className="h-3 w-3" />
      {h > 0 ? `${h}h ${m}m 后` : `${m}m 后`}
    </span>
  );
}

/* ─── Create / Edit Dialog ─── */
function CampaignFormDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const accounts = useQuery(api.accounts.list, {});
  const tags = useQuery(api.contacts.getAllTags, {});
  const templates = useQuery(api.messageTemplates.list, {});
  const createCampaign = useMutation(api.campaigns.create);

  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const [selectedAccount, setSelectedAccount] = useState("none");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [enableSchedule, setEnableSchedule] = useState(false);
  const [scheduledAt, setScheduledAt] = useState("");
  const [templateSearch, setTemplateSearch] = useState("");
  const [showTemplates, setShowTemplates] = useState(false);
  const [saving, setSaving] = useState(false);

  const reset = () => {
    setName(""); setContent(""); setSelectedAccount("none");
    setSelectedTags([]); setEnableSchedule(false);
    setScheduledAt(""); setTemplateSearch(""); setShowTemplates(false);
  };

  const filteredTemplates = templates?.filter((t) => {
    if (!templateSearch) return true;
    return t.name.toLowerCase().includes(templateSearch.toLowerCase()) ||
      t.content.toLowerCase().includes(templateSearch.toLowerCase());
  });

  const toggleTag = (tag: string) =>
    setSelectedTags((p) => p.includes(tag) ? p.filter((x) => x !== tag) : [...p, tag]);

  const handleCreate = async () => {
    if (!name.trim() || !content.trim()) {
      toast.error("请填写任务名称和消息内容");
      return;
    }
    if (enableSchedule && !scheduledAt) {
      toast.error("请选择发送时间");
      return;
    }
    if (enableSchedule && new Date(scheduledAt) <= new Date()) {
      toast.error("发送时间必须是未来时间");
      return;
    }
    setSaving(true);
    try {
      await createCampaign({
        name: name.trim(),
        content: content.trim(),
        accountId: selectedAccount !== "none" ? (selectedAccount as Id<"accounts">) : undefined,
        targetTags: selectedTags,
        scheduledAt: enableSchedule ? new Date(scheduledAt).toISOString() : undefined,
      });
      toast.success(enableSchedule ? "任务已排程" : "任务已创建（草稿）");
      reset();
      onOpenChange(false);
    } catch (err) {
      if (err instanceof ConvexError) {
        const d = err.data as { message: string };
        toast.error(d.message);
      } else {
        toast.error("创建失败");
      }
    } finally {
      setSaving(false);
    }
  };

  // Min datetime for input (now + 5 min)
  const minDatetime = new Date(Date.now() + 5 * 60 * 1000)
    .toISOString()
    .slice(0, 16);

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) reset(); onOpenChange(v); }}>
      <DialogContent className="max-w-xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>创建群发任务</DialogTitle>
        </DialogHeader>

        <div className="space-y-5">
          {/* Name */}
          <div className="space-y-1.5">
            <Label>任务名称 *</Label>
            <Input placeholder="例：5月促销推广" value={name} onChange={(e) => setName(e.target.value)} />
          </div>

          {/* Content + template picker */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label>消息内容 *</Label>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 text-xs gap-1 text-muted-foreground"
                onClick={() => setShowTemplates(!showTemplates)}
              >
                <BookOpen className="h-3 w-3" />
                从模板选择
              </Button>
            </div>

            {showTemplates && (
              <div className="rounded-lg border border-border/50 bg-muted/20 p-3 space-y-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                  <Input
                    className="pl-8 h-7 text-xs"
                    placeholder="搜索模板…"
                    value={templateSearch}
                    onChange={(e) => setTemplateSearch(e.target.value)}
                  />
                </div>
                <div className="max-h-44 overflow-y-auto space-y-1">
                  {filteredTemplates?.length === 0 && (
                    <p className="text-xs text-muted-foreground text-center py-2">暂无模板</p>
                  )}
                  {filteredTemplates?.map((t) => (
                    <button
                      key={t._id}
                      onClick={() => {
                        setContent(t.content);
                        setShowTemplates(false);
                        toast.success(`已使用模板：${t.name}`);
                      }}
                      className="w-full text-left px-3 py-2 rounded-md hover:bg-muted transition-colors"
                    >
                      <p className="text-xs font-medium">{t.name}</p>
                      <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{t.content}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <Textarea
              rows={5}
              placeholder={"你好 {{name}}，我们有一个专属优惠想和你分享…"}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="resize-none font-mono text-sm"
            />
            <p className="text-[11px] text-muted-foreground">
              支持变量：{`{{name}}`} {`{{phone}}`} 等占位符
            </p>
          </div>

          {/* Account */}
          <div className="space-y-1.5">
            <Label>发送账号</Label>
            <Select value={selectedAccount} onValueChange={setSelectedAccount}>
              <SelectTrigger>
                <SelectValue placeholder="不指定（随机选择）" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">不指定</SelectItem>
                {accounts?.map((acc) => (
                  <SelectItem key={acc._id} value={acc._id}>
                    {acc.name} · {acc.phone}
                    {acc.status === "connected" && " ✓"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Target tags */}
          <div className="space-y-1.5">
            <Label>目标受众标签</Label>
            <p className="text-[11px] text-muted-foreground">不选则发给所有联系人</p>
            {tags && tags.length > 0 ? (
              <div className="flex flex-wrap gap-1.5">
                {tags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => toggleTag(tag)}
                    className={cn(
                      "px-3 py-1 rounded-full text-xs font-medium border transition-colors",
                      selectedTags.includes(tag)
                        ? "bg-primary/10 text-primary border-primary/30"
                        : "bg-card border-border/60 text-muted-foreground hover:border-primary/20"
                    )}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">暂无联系人标签</p>
            )}
          </div>

          {/* Schedule toggle */}
          <div className="rounded-xl border border-border/50 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium flex items-center gap-2">
                  <CalendarClock className="h-4 w-4 text-primary" />
                  定时发送
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  开启后任务将在指定时间自动发送
                </p>
              </div>
              <Switch checked={enableSchedule} onCheckedChange={setEnableSchedule} />
            </div>

            {enableSchedule && (
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">发送时间</Label>
                <Input
                  type="datetime-local"
                  min={minDatetime}
                  value={scheduledAt}
                  onChange={(e) => setScheduledAt(e.target.value)}
                  className="text-sm"
                />
              </div>
            )}
          </div>

          <div className="flex gap-2 justify-end">
            <Button variant="secondary" size="sm" onClick={() => { reset(); onOpenChange(false); }}>
              取消
            </Button>
            <Button size="sm" onClick={() => void handleCreate()} disabled={saving} className="gap-1.5">
              {saving ? "创建中…" : enableSchedule ? (
                <><CalendarClock className="h-3.5 w-3.5" />排程发送</>
              ) : (
                <><Plus className="h-3.5 w-3.5" />保存草稿</>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ─── Schedule Edit Sheet ─── */
function ScheduleSheet({
  campaign,
  open,
  onOpenChange,
}: {
  campaign: Campaign | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const updateSchedule = useMutation(api.campaigns.updateSchedule);
  const [enableSchedule, setEnableSchedule] = useState(true);
  const [scheduledAt, setScheduledAt] = useState("");
  const [saving, setSaving] = useState(false);

  const minDatetime = new Date(Date.now() + 5 * 60 * 1000).toISOString().slice(0, 16);

  const handleSave = async () => {
    if (!campaign) return;
    if (enableSchedule && !scheduledAt) { toast.error("请选择时间"); return; }
    if (enableSchedule && new Date(scheduledAt) <= new Date()) {
      toast.error("发送时间必须是未来时间");
      return;
    }
    setSaving(true);
    try {
      await updateSchedule({
        campaignId: campaign._id,
        scheduledAt: enableSchedule ? new Date(scheduledAt).toISOString() : undefined,
      });
      toast.success(enableSchedule ? "排程已设置" : "已取消排程");
      onOpenChange(false);
    } catch {
      toast.error("更新失败");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="max-w-sm w-full">
        <SheetHeader>
          <SheetTitle>设置发送时间</SheetTitle>
        </SheetHeader>
        <div className="space-y-5 mt-6">
          <p className="text-sm text-muted-foreground">
            任务：<strong className="text-foreground">{campaign?.name}</strong>
          </p>
          <div className="flex items-center justify-between">
            <Label>启用定时发送</Label>
            <Switch checked={enableSchedule} onCheckedChange={setEnableSchedule} />
          </div>
          {enableSchedule && (
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">发送时间</Label>
              <Input
                type="datetime-local"
                min={minDatetime}
                value={scheduledAt}
                onChange={(e) => setScheduledAt(e.target.value)}
              />
            </div>
          )}
          <Button className="w-full" onClick={() => void handleSave()} disabled={saving}>
            {saving ? "保存中…" : "确认"}
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}

/* ─── Campaign Detail Sheet ─── */
function CampaignDetailSheet({
  campaign,
  open,
  onOpenChange,
}: {
  campaign: Campaign | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  if (!campaign) return null;
  const s = STATUS_MAP[campaign.status] ?? STATUS_MAP.draft;
  const total = campaign.totalRecipients;

  const stats = [
    { label: "目标", value: total, icon: Users, color: "text-muted-foreground" },
    { label: "已发送", value: campaign.sentCount, icon: Send, color: "text-blue-400", pct: total },
    { label: "已送达", value: campaign.deliveredCount, icon: CheckCircle2, color: "text-green-400", pct: campaign.sentCount },
    { label: "已阅读", value: campaign.readCount, icon: Eye, color: "text-primary", pct: campaign.deliveredCount },
    { label: "已回复", value: campaign.repliedCount, icon: MessageSquare, color: "text-yellow-400", pct: campaign.readCount },
  ];

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="max-w-sm w-full overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="truncate">{campaign.name}</SheetTitle>
        </SheetHeader>

        <div className="space-y-5 mt-4">
          {/* Status + schedule */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className={cn("text-xs px-2.5 py-1 rounded-full font-medium", s.badge)}>
              <span className={cn("inline-block w-1.5 h-1.5 rounded-full mr-1.5", s.dot)} />
              {s.label}
            </span>
            {campaign.scheduledAt && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {new Date(campaign.scheduledAt).toLocaleString("zh-CN")}
              </span>
            )}
          </div>

          {/* Stats funnel */}
          <div className="space-y-3">
            {stats.map(({ label, value, icon: Icon, color, pct }) => (
              <div key={label} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-muted-foreground">
                    <Icon className={cn("h-3.5 w-3.5", color)} />
                    {label}
                  </span>
                  <span className="font-medium">
                    {value}
                    {pct !== undefined && pct > 0 && (
                      <span className="text-muted-foreground ml-1">
                        ({Math.round((value / pct) * 100)}%)
                      </span>
                    )}
                  </span>
                </div>
                {pct !== undefined && (
                  <ProgressBar value={value} max={pct} color={color.replace("text-", "bg-")} />
                )}
              </div>
            ))}
          </div>

          {/* Tags */}
          {campaign.targetTags.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-xs text-muted-foreground font-medium">目标标签</p>
              <div className="flex flex-wrap gap-1.5">
                {campaign.targetTags.map((t) => (
                  <Badge key={t} variant="secondary" className="text-xs">{t}</Badge>
                ))}
              </div>
            </div>
          )}

          {/* Content */}
          <div className="space-y-1.5">
            <p className="text-xs text-muted-foreground font-medium">消息内容</p>
            <div className="rounded-lg bg-muted/30 border border-border/40 p-3">
              <p className="text-xs whitespace-pre-wrap leading-relaxed">{campaign.content}</p>
            </div>
          </div>

          <p className="text-[11px] text-muted-foreground">
            创建于 {new Date(campaign.createdAt).toLocaleString("zh-CN")}
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
}

/* ─── Main Page ─── */
export default function CampaignsPage() {
  const campaigns = useQuery(api.campaigns.list, {});
  const updateStatus = useMutation(api.campaigns.updateStatus);
  const removeCampaign = useMutation(api.campaigns.remove);
  const duplicateCampaign = useMutation(api.campaigns.duplicate);

  const [createOpen, setCreateOpen] = useState(false);
  const [scheduleTarget, setScheduleTarget] = useState<Campaign | null>(null);
  const [detailTarget, setDetailTarget] = useState<Campaign | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Campaign | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [search, setSearch] = useState("");

  const handleStatusChange = async (id: Id<"campaigns">, status: "running" | "paused" | "completed") => {
    try {
      await updateStatus({ campaignId: id, status });
      toast.success(status === "running" ? "任务开始发送" : status === "paused" ? "任务已暂停" : "任务已标记完成");
    } catch { toast.error("更新失败"); }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await removeCampaign({ campaignId: deleteTarget._id });
      toast.success("已删除");
    } catch { toast.error("删除失败"); }
    finally { setDeleteTarget(null); }
  };

  const handleDuplicate = async (id: Id<"campaigns">) => {
    try {
      await duplicateCampaign({ campaignId: id });
      toast.success("已复制为草稿");
    } catch { toast.error("复制失败"); }
  };

  const filtered = campaigns?.filter((c) => {
    if (statusFilter !== "all" && c.status !== statusFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return c.name.toLowerCase().includes(q) || c.content.toLowerCase().includes(q);
    }
    return true;
  });

  if (campaigns === undefined) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">群发任务</h1>
        <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}</div>
      </div>
    );
  }

  const statusCounts = Object.keys(STATUS_MAP).reduce((acc, k) => {
    acc[k] = campaigns.filter((c) => c.status === k).length;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Send className="h-6 w-6 text-primary" />
            群发任务
          </h1>
          <p className="text-sm text-muted-foreground mt-1">共 {campaigns.length} 个任务</p>
        </div>
        <Button size="sm" className="gap-1.5 shrink-0" onClick={() => setCreateOpen(true)}>
          <Plus className="h-4 w-4" />
          创建任务
        </Button>
      </div>

      {/* Filter bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="搜索任务名称或内容…" className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {[{ value: "all", label: "全部", count: campaigns.length }, ...Object.entries(STATUS_MAP).map(([k, v]) => ({ value: k, label: v.label, count: statusCounts[k] ?? 0 }))]
            .filter(({ count }) => count > 0 || statusFilter === "all")
            .map(({ value, label, count }) => (
              <button
                key={value}
                onClick={() => setStatusFilter(value)}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-medium border transition-all",
                  statusFilter === value
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-border/50 bg-card/40 text-muted-foreground hover:text-foreground hover:border-border"
                )}
              >
                {label} {count > 0 && <span className="ml-1 opacity-70">{count}</span>}
              </button>
            ))}
        </div>
      </div>

      {/* Empty */}
      {filtered?.length === 0 && (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Send /></EmptyMedia>
            <EmptyTitle>{search || statusFilter !== "all" ? "没有匹配的任务" : "暂无群发任务"}</EmptyTitle>
            <EmptyDescription>
              {search || statusFilter !== "all" ? "尝试其他筛选条件" : "创建你的第一个群发任务"}
            </EmptyDescription>
          </EmptyHeader>
          {!search && statusFilter === "all" && (
            <EmptyContent>
              <Button size="sm" onClick={() => setCreateOpen(true)}>
                <Plus className="h-4 w-4 mr-1" />创建任务
              </Button>
            </EmptyContent>
          )}
        </Empty>
      )}

      {/* Campaign cards */}
      <div className="space-y-3">
        {filtered?.map((campaign) => {
          const s = STATUS_MAP[campaign.status] ?? STATUS_MAP.draft;
          const total = campaign.totalRecipients;
          const sentPct = total > 0 ? Math.round((campaign.sentCount / total) * 100) : 0;

          return (
            <Card key={campaign._id} className="hover:border-border transition-colors group">
              <CardContent className="pt-4 pb-4">
                <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                  {/* Left: info */}
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-sm truncate max-w-[240px]">{campaign.name}</h3>
                      <span className={cn("text-[10px] px-2 py-0.5 rounded-full font-medium flex items-center gap-1", s.badge)}>
                        <span className={cn("w-1.5 h-1.5 rounded-full", s.dot)} />
                        {s.label}
                      </span>
                      {campaign.scheduledAt && campaign.status === "scheduled" && (
                        <CountdownBadge scheduledAt={campaign.scheduledAt} />
                      )}
                    </div>

                    <p className="text-xs text-muted-foreground line-clamp-1">{campaign.content}</p>

                    {/* Stats row */}
                    <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                      <span className="flex items-center gap-1"><Users className="h-3 w-3" />{total}</span>
                      <span className="flex items-center gap-1"><Send className="h-3 w-3" />{campaign.sentCount}</span>
                      <span className="flex items-center gap-1"><CheckCircle2 className="h-3 w-3 text-green-400" />{campaign.deliveredCount}</span>
                      <span className="flex items-center gap-1"><Eye className="h-3 w-3 text-primary" />{campaign.readCount}</span>
                      <span className="flex items-center gap-1"><MessageSquare className="h-3 w-3 text-yellow-400" />{campaign.repliedCount}</span>
                      {campaign.scheduledAt && (
                        <span className="flex items-center gap-1 text-blue-400">
                          <Clock className="h-3 w-3" />
                          {new Date(campaign.scheduledAt).toLocaleString("zh-CN", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                        </span>
                      )}
                    </div>

                    {/* Progress bar */}
                    {(campaign.status === "running" || campaign.status === "completed") && total > 0 && (
                      <div className="space-y-0.5">
                        <ProgressBar value={campaign.sentCount} max={total} color="bg-primary" />
                        <p className="text-[10px] text-muted-foreground">{sentPct}% 已发送</p>
                      </div>
                    )}
                  </div>

                  {/* Right: actions */}
                  <div className="flex items-center gap-1 shrink-0">
                    {(campaign.status === "draft" || campaign.status === "paused") && (
                      <Button size="icon-sm" variant="ghost" title="开始发送"
                        onClick={() => void handleStatusChange(campaign._id, "running")}>
                        <Play className="h-4 w-4 text-primary" />
                      </Button>
                    )}
                    {campaign.status === "running" && (
                      <Button size="icon-sm" variant="ghost" title="暂停"
                        onClick={() => void handleStatusChange(campaign._id, "paused")}>
                        <Pause className="h-4 w-4 text-yellow-400" />
                      </Button>
                    )}
                    {campaign.status === "draft" && (
                      <Button size="icon-sm" variant="ghost" title="设置排程"
                        onClick={() => setScheduleTarget(campaign)}>
                        <CalendarClock className="h-4 w-4 text-blue-400" />
                      </Button>
                    )}
                    <Button size="icon-sm" variant="ghost" title="复制"
                      onClick={() => void handleDuplicate(campaign._id)}>
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button size="icon-sm" variant="ghost" title="详情"
                      onClick={() => setDetailTarget(campaign)}>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    <Button size="icon-sm" variant="ghost"
                      className="text-muted-foreground hover:text-destructive" title="删除"
                      onClick={() => setDeleteTarget(campaign)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Dialogs & Sheets */}
      <CampaignFormDialog open={createOpen} onOpenChange={setCreateOpen} />

      <ScheduleSheet
        campaign={scheduleTarget}
        open={!!scheduleTarget}
        onOpenChange={(v) => !v && setScheduleTarget(null)}
      />

      <CampaignDetailSheet
        campaign={detailTarget}
        open={!!detailTarget}
        onOpenChange={(v) => !v && setDetailTarget(null)}
      />

      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除任务？</AlertDialogTitle>
            <AlertDialogDescription>
              将删除任务 <strong>{deleteTarget?.name}</strong>，此操作不可撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDelete()}>确认删除</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
