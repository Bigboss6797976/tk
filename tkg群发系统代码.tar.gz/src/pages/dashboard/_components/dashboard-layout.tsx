import { Outlet, NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  Send,
  Smartphone,
  Sparkles,
  BarChart3,
  MessageSquare,
  BookOpen,
  Menu,
  X,
  LogOut,
  Settings,
  Inbox,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils.ts";
import { useAuth } from "@/hooks/use-auth.ts";

const NAV_ITEMS = [
  { to: "/dashboard", icon: LayoutDashboard, label: "仪表盘" },
  { to: "/dashboard/inbox", icon: Inbox, label: "收件箱" },
  { to: "/dashboard/contacts", icon: Users, label: "联系人" },
  { to: "/dashboard/campaigns", icon: Send, label: "群发任务" },
  { to: "/dashboard/accounts", icon: Smartphone, label: "账号管理" },
  { to: "/dashboard/ai-copy", icon: Sparkles, label: "AI 文案" },
  { to: "/dashboard/templates", icon: BookOpen, label: "模板库" },
  { to: "/dashboard/analytics", icon: BarChart3, label: "数据分析" },
  { to: "/dashboard/settings", icon: Settings, label: "账号设置" },
];

export default function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { removeUser, user } = useAuth();
  const location = useLocation();

  return (
    <div className="min-h-screen bg-background flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed top-0 left-0 z-50 h-full w-64 border-r border-border bg-card flex flex-col transition-transform duration-300 lg:translate-x-0 lg:static lg:z-auto",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Logo */}
        <div className="flex items-center gap-2.5 px-6 py-5 border-b border-border">
          <div className="size-8 rounded-lg bg-primary/20 flex items-center justify-center">
            <MessageSquare className="size-4 text-primary" />
          </div>
          <span className="text-sm font-bold tracking-tight">
            TK-G <span className="text-primary">V16.0</span>
          </span>
          <button
            className="ml-auto lg:hidden text-muted-foreground"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="size-5" />
          </button>
        </div>

        {/* Nav items */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {NAV_ITEMS.map((item) => {
            const isActive =
              item.to === "/dashboard"
                ? location.pathname === "/dashboard"
                : location.pathname.startsWith(item.to);

            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-accent hover:text-foreground"
                )}
              >
                <item.icon className="size-4.5 shrink-0" />
                {item.label}
              </NavLink>
            );
          })}
        </nav>

        {/* User */}
        <div className="px-4 py-4 border-t border-border">
          <div className="flex items-center gap-3">
            <div className="size-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">
              {user?.profile?.name?.[0] ?? "U"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">
                {user?.profile?.name ?? "用户"}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {user?.profile?.email ?? ""}
              </p>
            </div>
            <button
              onClick={() => removeUser()}
              className="text-muted-foreground hover:text-foreground transition-colors"
              title="退出登录"
            >
              <LogOut className="size-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile header */}
        <header className="lg:hidden flex items-center gap-3 px-4 py-3 border-b border-border bg-card">
          <button onClick={() => setSidebarOpen(true)}>
            <Menu className="size-5 text-foreground" />
          </button>
          <div className="flex items-center gap-2">
            <MessageSquare className="size-4 text-primary" />
            <span className="text-sm font-bold">
              TK-G <span className="text-primary">V16.0</span>
            </span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
