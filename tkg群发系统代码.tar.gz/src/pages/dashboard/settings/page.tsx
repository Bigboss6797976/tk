import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import {
  User,
  Bell,
  Shield,
  Globe,
  Building2,
  Phone,
  FileText,
  Clock,
  Languages,
  CheckCircle2,
  LogOut,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { useAuth } from "@/hooks/use-auth.ts";
import { cn } from "@/lib/utils.ts";

const TIMEZONES = [
  "Asia/Shanghai",
  "Asia/Hong_Kong",
  "Asia/Taipei",
  "Asia/Tokyo",
  "Asia/Singapore",
  "Asia/Seoul",
  "UTC",
  "America/New_York",
  "America/Los_Angeles",
  "Europe/London",
  "Europe/Paris",
];

const LANGUAGES = [
  { value: "zh-CN", label: "简体中文" },
  { value: "zh-TW", label: "繁體中文" },
  { value: "en", label: "English" },
];

type Tab = "profile" | "notifications" | "security";

const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "profile", label: "个人资料", icon: User },
  { id: "notifications", label: "通知设置", icon: Bell },
  { id: "security", label: "账号安全", icon: Shield },
];

export default function SettingsPage() {
  const { user, removeUser } = useAuth();
  const currentUser = useQuery(api.users.getCurrentUser, {});
  const updateProfile = useMutation(api.users.updateProfile);
  const updateNotifications = useMutation(api.users.updateNotifications);

  const [activeTab, setActiveTab] = useState<Tab>("profile");
  const [saving, setSaving] = useState(false);

  // Profile form state
  const [name, setName] = useState("");
  const [company, setCompany] = useState("");
  const [phone, setPhone] = useState("");
  const [bio, setBio] = useState("");
  const [timezone, setTimezone] = useState("Asia/Shanghai");
  const [language, setLanguage] = useState("zh-CN");

  // Notification state
  const [notifyOnReply, setNotifyOnReply] = useState(true);
  const [notifyOnDelivery, setNotifyOnDelivery] = useState(false);
  const [notifyOnFailure, setNotifyOnFailure] = useState(true);

  // Populate form from DB
  useEffect(() => {
    if (!currentUser) return;
    setName(currentUser.name ?? "");
    setCompany(currentUser.company ?? "");
    setPhone(currentUser.phone ?? "");
    setBio(currentUser.bio ?? "");
    setTimezone(currentUser.timezone ?? "Asia/Shanghai");
    setLanguage(currentUser.language ?? "zh-CN");
    setNotifyOnReply(currentUser.notifyOnReply ?? true);
    setNotifyOnDelivery(currentUser.notifyOnDelivery ?? false);
    setNotifyOnFailure(currentUser.notifyOnFailure ?? true);
  }, [currentUser]);

  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      await updateProfile({ name, company, phone, bio, timezone, language });
      toast.success("资料已保存");
    } catch (err) {
      if (err instanceof ConvexError) {
        const { message } = err.data as { message: string };
        toast.error(message);
      } else {
        toast.error("保存失败，请重试");
      }
    } finally {
      setSaving(false);
    }
  };

  const handleSaveNotifications = async () => {
    setSaving(true);
    try {
      await updateNotifications({ notifyOnReply, notifyOnDelivery, notifyOnFailure });
      toast.success("通知设置已保存");
    } catch (err) {
      if (err instanceof ConvexError) {
        const { message } = err.data as { message: string };
        toast.error(message);
      } else {
        toast.error("保存失败，请重试");
      }
    } finally {
      setSaving(false);
    }
  };

  const isLoading = currentUser === undefined;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">账号设置</h1>
        <p className="text-muted-foreground text-sm mt-1">管理个人资料、通知与安全选项</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-muted rounded-xl w-fit">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
              activeTab === tab.id
                ? "bg-background text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <tab.icon className="size-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Profile Tab */}
      {activeTab === "profile" && (
        <div className="space-y-6">
          {/* Avatar Card */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-5">
                <div className="size-16 rounded-full bg-primary/20 flex items-center justify-center text-2xl font-bold text-primary shrink-0">
                  {isLoading ? (
                    <Skeleton className="size-16 rounded-full" />
                  ) : (
                    (name || user?.profile?.name || "U")[0].toUpperCase()
                  )}
                </div>
                <div>
                  <p className="font-semibold text-lg">{user?.profile?.name ?? "用户"}</p>
                  <p className="text-sm text-muted-foreground">{user?.profile?.email ?? ""}</p>
                  <Badge variant="secondary" className="mt-1.5 text-xs">
                    免费版
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Form Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <User className="size-4 text-primary" /> 基本信息
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {isLoading ? (
                <div className="space-y-4">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="name">姓名</Label>
                      <Input
                        id="name"
                        placeholder="张三"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="email">邮箱</Label>
                      <Input
                        id="email"
                        value={user?.profile?.email ?? ""}
                        disabled
                        className="opacity-60"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="company" className="flex items-center gap-1.5">
                        <Building2 className="size-3.5" /> 公司 / 团队
                      </Label>
                      <Input
                        id="company"
                        placeholder="我的公司"
                        value={company}
                        onChange={(e) => setCompany(e.target.value)}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="phone" className="flex items-center gap-1.5">
                        <Phone className="size-3.5" /> 手机号
                      </Label>
                      <Input
                        id="phone"
                        placeholder="+86 138 0000 0000"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="bio" className="flex items-center gap-1.5">
                      <FileText className="size-3.5" /> 个人简介
                    </Label>
                    <Textarea
                      id="bio"
                      placeholder="简单介绍一下自己..."
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      rows={3}
                      className="resize-none"
                    />
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Preferences Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Globe className="size-4 text-primary" /> 偏好设置
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="timezone" className="flex items-center gap-1.5">
                      <Clock className="size-3.5" /> 时区
                    </Label>
                    <select
                      id="timezone"
                      value={timezone}
                      onChange={(e) => setTimezone(e.target.value)}
                      className="w-full h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      {TIMEZONES.map((tz) => (
                        <option key={tz} value={tz}>{tz}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="language" className="flex items-center gap-1.5">
                      <Languages className="size-3.5" /> 界面语言
                    </Label>
                    <select
                      id="language"
                      value={language}
                      onChange={(e) => setLanguage(e.target.value)}
                      className="w-full h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      {LANGUAGES.map((lang) => (
                        <option key={lang.value} value={lang.value}>{lang.label}</option>
                      ))}
                    </select>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button onClick={handleSaveProfile} disabled={saving || isLoading} className="px-8">
              {saving ? "保存中..." : "保存更改"}
            </Button>
          </div>
        </div>
      )}

      {/* Notifications Tab */}
      {activeTab === "notifications" && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Bell className="size-4 text-primary" /> 消息通知
              </CardTitle>
              <CardDescription>选择哪些事件需要通知你</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              {isLoading ? (
                <div className="space-y-4">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : (
                <>
                  {[
                    {
                      id: "reply",
                      label: "联系人回复",
                      desc: "当联系人回复你的消息时收到通知",
                      value: notifyOnReply,
                      onChange: setNotifyOnReply,
                    },
                    {
                      id: "delivery",
                      label: "消息送达",
                      desc: "群发消息成功送达时收到通知",
                      value: notifyOnDelivery,
                      onChange: setNotifyOnDelivery,
                    },
                    {
                      id: "failure",
                      label: "发送失败",
                      desc: "消息发送失败时收到通知",
                      value: notifyOnFailure,
                      onChange: setNotifyOnFailure,
                    },
                  ].map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/30"
                    >
                      <div>
                        <p className="text-sm font-medium">{item.label}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{item.desc}</p>
                      </div>
                      <Switch
                        checked={item.value}
                        onCheckedChange={item.onChange}
                      />
                    </div>
                  ))}
                </>
              )}
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button onClick={handleSaveNotifications} disabled={saving || isLoading} className="px-8">
              {saving ? "保存中..." : "保存设置"}
            </Button>
          </div>
        </div>
      )}

      {/* Security Tab */}
      {activeTab === "security" && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Shield className="size-4 text-primary" /> 账号安全
              </CardTitle>
              <CardDescription>管理登录方式和账号安全</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Auth method */}
              <div className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/30">
                <div className="flex items-center gap-3">
                  <div className="size-9 rounded-lg bg-primary/10 flex items-center justify-center">
                    <CheckCircle2 className="size-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">安全登录</p>
                    <p className="text-xs text-muted-foreground">通过 Google / 邮件登录</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-green-600 border-green-300 bg-green-50 dark:bg-green-950">
                  已连接
                </Badge>
              </div>

              {/* Account info */}
              <div className="p-4 rounded-xl border border-border space-y-3">
                <p className="text-sm font-medium text-muted-foreground">账号信息</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground">邮箱：</span>
                    <span className="font-medium">{user?.profile?.email ?? "-"}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">账号 ID：</span>
                    <span className="font-mono text-xs text-muted-foreground">
                      {user?.profile?.sub?.slice(0, 16) ?? "-"}...
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Danger zone */}
          <Card className="border-destructive/30">
            <CardHeader>
              <CardTitle className="text-base text-destructive">危险区域</CardTitle>
              <CardDescription>这些操作不可撤销，请谨慎操作</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between p-4 rounded-xl border border-destructive/20 bg-destructive/5">
                <div>
                  <p className="text-sm font-medium">退出登录</p>
                  <p className="text-xs text-muted-foreground mt-0.5">从当前设备退出账号</p>
                </div>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => removeUser()}
                  className="gap-2"
                >
                  <LogOut className="size-4" />
                  退出
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
