import { toast } from "sonner";
import { Send, Sparkles, BarChart3 } from "lucide-react";

const COMING_SOON_PAGES = {
  "ai-copy": { icon: Sparkles, title: "AI 文案助手", desc: "即将在下一个里程碑中构建" },
  analytics: { icon: BarChart3, title: "数据分析看板", desc: "即将在后续里程碑中构建" },
};

export function showComingSoon(feature: string) {
  toast.info(`${feature} 功能即将推出！`);
}

export default COMING_SOON_PAGES;
