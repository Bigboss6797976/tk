import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  Copy,
  BookOpen,
  BarChart2,
  Tag,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent, CardHeader } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import TemplateFormDialog from "./_components/template-form-dialog.tsx";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";

type Category = "marketing" | "followup" | "greeting" | "promotion" | "custom";
type Template = Doc<"messageTemplates">;

const CATEGORIES: { value: Category | "all"; label: string; color: string }[] = [
  { value: "all", label: "全部", color: "text-foreground" },
  { value: "marketing", label: "营销推广", color: "text-primary" },
  { value: "followup", label: "客户跟进", color: "text-blue-400" },
  { value: "greeting", label: "问候祝福", color: "text-yellow-400" },
  { value: "promotion", label: "促销活动", color: "text-orange-400" },
  { value: "custom", label: "自定义", color: "text-purple-400" },
];

const CATEGORY_BADGE_CLASS: Record<Category, string> = {
  marketing: "bg-primary/15 text-primary border-primary/30",
  followup: "bg-blue-400/15 text-blue-400 border-blue-400/30",
  greeting: "bg-yellow-400/15 text-yellow-400 border-yellow-400/30",
  promotion: "bg-orange-400/15 text-orange-400 border-orange-400/30",
  custom: "bg-purple-400/15 text-purple-400 border-purple-400/30",
};

function extractVars(content: string): string[] {
  const matches = content.matchAll(/\{\{(\w+)\}\}/g);
  return [...new Set([...matches].map((m) => m[1]))];
}

function TemplateCard({
  tpl,
  onEdit,
  onDelete,
  onCopy,
}: {
  tpl: Template;
  onEdit: (t: Template) => void;
  onDelete: (t: Template) => void;
  onCopy: (t: Template) => void;
}) {
  const vars = extractVars(tpl.content);

  return (
    <Card className="group hover:border-primary/40 transition-colors flex flex-col">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-sm truncate">{tpl.name}</p>
            <div className="flex items-center gap-1.5 mt-1 flex-wrap">
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded border font-medium ${CATEGORY_BADGE_CLASS[tpl.category]}`}
              >
                {CATEGORIES.find((c) => c.value === tpl.category)?.label}
              </span>
              {tpl.tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="text-[10px] h-4 px-1.5">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
          {/* Actions – visible on hover */}
          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
            <Button
              size="icon-sm"
              variant="ghost"
              className="h-7 w-7"
              onClick={() => onCopy(tpl)}
              title="复制内容"
            >
              <Copy className="h-3.5 w-3.5" />
            </Button>
            <Button
              size="icon-sm"
              variant="ghost"
              className="h-7 w-7"
              onClick={() => onEdit(tpl)}
              title="编辑"
            >
              <Pencil className="h-3.5 w-3.5" />
            </Button>
            <Button
              size="icon-sm"
              variant="ghost"
              className="h-7 w-7 text-destructive hover:text-destructive"
              onClick={() => onDelete(tpl)}
              title="删除"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col gap-3 pb-4">
        {/* Content preview */}
        <p className="text-xs text-muted-foreground line-clamp-4 whitespace-pre-wrap leading-relaxed flex-1">
          {tpl.content}
        </p>

        {/* Variables */}
        {vars.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {vars.map((v) => (
              <span
                key={v}
                className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted border border-border/60 text-muted-foreground"
              >
                {`{{${v}}}`}
              </span>
            ))}
          </div>
        )}

        {/* Footer stats */}
        <div className="flex items-center justify-between text-[10px] text-muted-foreground border-t border-border/40 pt-2">
          <span className="flex items-center gap-1">
            <BarChart2 className="h-3 w-3" />
            使用 {tpl.usageCount} 次
          </span>
          <span>
            {new Date(tpl.updatedAt).toLocaleDateString("zh-CN", {
              month: "short",
              day: "numeric",
            })}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function TemplatesPage() {
  const [activeCategory, setActiveCategory] = useState<Category | "all">("all");
  const [search, setSearch] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Template | null>(null);
  const [deleting, setDeleting] = useState<Template | null>(null);

  const templates = useQuery(
    api.messageTemplates.list,
    activeCategory === "all" ? {} : { category: activeCategory }
  );
  const removeTpl = useMutation(api.messageTemplates.remove);
  const incrementUsage = useMutation(api.messageTemplates.incrementUsage);

  const filtered = templates?.filter((t) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      t.name.toLowerCase().includes(q) ||
      t.content.toLowerCase().includes(q) ||
      t.tags.some((tag) => tag.toLowerCase().includes(q))
    );
  });

  const handleEdit = (tpl: Template) => {
    setEditing(tpl);
    setFormOpen(true);
  };

  const handleNew = () => {
    setEditing(null);
    setFormOpen(true);
  };

  const handleCopy = async (tpl: Template) => {
    await navigator.clipboard.writeText(tpl.content);
    toast.success("已复制到剪贴板");
    await incrementUsage({ id: tpl._id });
  };

  const handleDelete = async () => {
    if (!deleting) return;
    try {
      await removeTpl({ id: deleting._id });
      toast.success("模板已删除");
    } catch (err) {
      if (err instanceof ConvexError) {
        const d = err.data as { message: string };
        toast.error(d.message);
      } else {
        toast.error("删除失败");
      }
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-primary" />
            消息模板库
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            管理和复用 WhatsApp 消息模板，支持变量占位符
          </p>
        </div>
        <Button size="sm" className="gap-1.5 shrink-0" onClick={handleNew}>
          <Plus className="h-4 w-4" />
          新建模板
        </Button>
      </div>

      {/* Category tabs */}
      <div className="flex gap-1.5 flex-wrap">
        {CATEGORIES.map((c) => {
          const count =
            c.value === "all"
              ? (templates?.length ?? 0)
              : (templates?.filter((t) => t.category === c.value).length ?? 0);
          return (
            <button
              key={c.value}
              onClick={() => setActiveCategory(c.value)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${
                activeCategory === c.value
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border/50 bg-card/40 text-muted-foreground hover:text-foreground hover:border-border"
              }`}
            >
              {c.label}
              {count > 0 && (
                <span
                  className={`ml-1.5 text-[10px] px-1 rounded-full ${
                    activeCategory === c.value ? "bg-primary-foreground/20" : "bg-muted"
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="搜索模板名称、内容或标签…"
          className="pl-9"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Loading */}
      {templates === undefined && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-48 w-full rounded-xl" />
          ))}
        </div>
      )}

      {/* Empty */}
      {templates !== undefined && filtered?.length === 0 && (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              {search ? <Tag /> : <BookOpen />}
            </EmptyMedia>
            <EmptyTitle>{search ? "没有匹配的模板" : "暂无模板"}</EmptyTitle>
            <EmptyDescription>
              {search
                ? "尝试其他关键词"
                : "创建第一个消息模板，快速复用常用文案"}
            </EmptyDescription>
          </EmptyHeader>
          {!search && (
            <EmptyContent>
              <Button size="sm" onClick={handleNew}>
                <Plus className="h-4 w-4 mr-1" />
                新建模板
              </Button>
            </EmptyContent>
          )}
        </Empty>
      )}

      {/* Grid */}
      {filtered && filtered.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((tpl) => (
            <TemplateCard
              key={tpl._id}
              tpl={tpl}
              onEdit={handleEdit}
              onDelete={setDeleting}
              onCopy={(t) => void handleCopy(t)}
            />
          ))}
        </div>
      )}

      {/* Form dialog */}
      <TemplateFormDialog
        open={formOpen}
        onOpenChange={(v) => {
          setFormOpen(v);
          if (!v) setEditing(null);
        }}
        editing={editing}
      />

      {/* Delete confirm */}
      <AlertDialog open={!!deleting} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除模板？</AlertDialogTitle>
            <AlertDialogDescription>
              将删除模板 <strong>{deleting?.name}</strong>，此操作不可撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDelete()}>
              确认删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
