import { useState, useEffect } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { Wand2, X, Plus, Eye } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";

type Category = "marketing" | "followup" | "greeting" | "promotion" | "custom";
type Template = Doc<"messageTemplates">;

const CATEGORIES: { value: Category; label: string }[] = [
  { value: "marketing", label: "营销推广" },
  { value: "followup", label: "客户跟进" },
  { value: "greeting", label: "问候祝福" },
  { value: "promotion", label: "促销活动" },
  { value: "custom", label: "自定义" },
];

// Extract {{variable}} placeholders from content
function extractVars(content: string): string[] {
  const matches = content.matchAll(/\{\{(\w+)\}\}/g);
  return [...new Set([...matches].map((m) => m[1]))];
}

// Replace variables with sample values for preview
function renderPreview(content: string, vars: Record<string, string>): string {
  return content.replace(/\{\{(\w+)\}\}/g, (_, key: string) => vars[key] ?? `{{${key}}}`);
}

const SAMPLE_VAR_VALUES: Record<string, string> = {
  name: "张三",
  phone: "+60123456789",
  product: "健康奶茶",
  price: "RM 29.90",
  discount: "8折",
  date: "12月31日",
  link: "https://example.com",
  code: "VIP2024",
  company: "TK营销",
};

export default function TemplateFormDialog({
  open,
  onOpenChange,
  editing,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editing?: Template | null;
}) {
  const createTpl = useMutation(api.messageTemplates.create);
  const updateTpl = useMutation(api.messageTemplates.update);

  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<Category>("marketing");
  const [tagInput, setTagInput] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (editing) {
      setName(editing.name);
      setContent(editing.content);
      setCategory(editing.category);
      setTags(editing.tags);
    } else {
      setName("");
      setContent("");
      setCategory("marketing");
      setTags([]);
    }
    setTagInput("");
  }, [editing, open]);

  const vars = extractVars(content);
  const [varValues, setVarValues] = useState<Record<string, string>>({});

  // Auto-fill sample values for known vars
  const previewVars: Record<string, string> = {};
  for (const v of vars) {
    previewVars[v] = varValues[v] ?? SAMPLE_VAR_VALUES[v] ?? `[${v}]`;
  }

  const insertVar = (varName: string) => {
    setContent((c) => c + `{{${varName}}}`);
  };

  const addTag = () => {
    const t = tagInput.trim();
    if (t && !tags.includes(t)) setTags((prev) => [...prev, t]);
    setTagInput("");
  };

  const handleSave = async () => {
    if (!name.trim()) { toast.error("请输入模板名称"); return; }
    if (!content.trim()) { toast.error("请输入模板内容"); return; }
    setSaving(true);
    try {
      if (editing) {
        await updateTpl({ id: editing._id, name: name.trim(), content, category, tags });
        toast.success("模板已更新");
      } else {
        await createTpl({ name: name.trim(), content, category, tags });
        toast.success("模板已保存");
      }
      onOpenChange(false);
    } catch (err) {
      if (err instanceof ConvexError) {
        const d = err.data as { message: string };
        toast.error(d.message);
      } else {
        toast.error("保存失败");
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{editing ? "编辑模板" : "新建模板"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Name + Category row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>模板名称 *</Label>
              <Input
                placeholder="例如：新客户问候语"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label>分类</Label>
              <Select value={category} onValueChange={(v) => setCategory(v as Category)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c.value} value={c.value}>
                      {c.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Content editor + preview tabs */}
          <Tabs defaultValue="edit">
            <TabsList className="h-8">
              <TabsTrigger value="edit" className="text-xs gap-1.5">
                <Wand2 className="h-3 w-3" /> 编辑
              </TabsTrigger>
              <TabsTrigger value="preview" className="text-xs gap-1.5">
                <Eye className="h-3 w-3" /> 预览
              </TabsTrigger>
            </TabsList>

            <TabsContent value="edit" className="space-y-3 mt-3">
              <div className="space-y-1.5">
                <Label>模板内容 *</Label>
                <Textarea
                  placeholder={"你好 {{name}}！👋\n\n我们有一个特别优惠想和你分享…"}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={7}
                  className="resize-none font-mono text-sm"
                />
              </div>

              {/* Quick insert variable buttons */}
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">快速插入变量占位符</Label>
                <div className="flex flex-wrap gap-1.5">
                  {["name", "phone", "product", "price", "discount", "date", "link", "code", "company"].map((v) => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => insertVar(v)}
                      className="text-[11px] px-2 py-0.5 rounded border border-primary/40 text-primary hover:bg-primary/10 transition-colors font-mono"
                    >
                      {`{{${v}}}`}
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground">
                  也可以手动输入 {`{{自定义变量}}`}，发送时会替换为实际值
                </p>
              </div>
            </TabsContent>

            <TabsContent value="preview" className="mt-3 space-y-3">
              {/* Variable fill-in */}
              {vars.length > 0 && (
                <div className="rounded-lg bg-muted/30 border border-border/40 p-3 space-y-2">
                  <p className="text-xs font-medium text-muted-foreground">预览变量值（可修改）</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {vars.map((v) => (
                      <div key={v} className="space-y-0.5">
                        <label className="text-[10px] text-muted-foreground font-mono">{`{{${v}}}`}</label>
                        <Input
                          className="h-7 text-xs"
                          value={varValues[v] ?? SAMPLE_VAR_VALUES[v] ?? ""}
                          onChange={(e) =>
                            setVarValues((prev) => ({ ...prev, [v]: e.target.value }))
                          }
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* WhatsApp-style preview bubble */}
              <div className="bg-[oklch(0.20_0.01_155)] rounded-xl p-4 min-h-[120px]">
                <div className="max-w-xs bg-[oklch(0.26_0.02_155)] rounded-2xl rounded-tl-none px-4 py-3 shadow-sm">
                  <p className="text-sm whitespace-pre-wrap leading-relaxed text-foreground">
                    {content
                      ? renderPreview(content, previewVars)
                      : <span className="text-muted-foreground text-xs italic">在编辑标签输入内容…</span>
                    }
                  </p>
                  <p className="text-[10px] text-muted-foreground text-right mt-1.5">
                    {new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })} ✓✓
                  </p>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Tags */}
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">标签（可选）</Label>
            <div className="flex gap-2">
              <Input
                className="h-8 text-xs"
                placeholder="输入标签后按回车"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addTag(); } }}
              />
              <Button size="sm" variant="secondary" className="h-8 px-3" onClick={addTag}>
                <Plus className="h-3.5 w-3.5" />
              </Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {tags.map((t) => (
                  <Badge key={t} variant="secondary" className="gap-1 text-xs pr-1">
                    {t}
                    <button onClick={() => setTags((prev) => prev.filter((x) => x !== t))}>
                      <X className="h-2.5 w-2.5" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <Button variant="secondary" size="sm" onClick={() => onOpenChange(false)}>
              取消
            </Button>
            <Button size="sm" onClick={() => void handleSave()} disabled={saving}>
              {saving ? "保存中…" : editing ? "保存更改" : "创建模板"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
