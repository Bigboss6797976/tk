import { useState } from "react";
import { useAction, useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import {
  Sparkles,
  Wand2,
  Copy,
  Trash2,
  Clock,
  ChevronDown,
  ChevronUp,
  Send,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
} from "@/components/ui/empty.tsx";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type Category = "marketing" | "followup" | "greeting" | "promotion" | "custom";

const CATEGORIES: { value: Category; label: string; description: string }[] = [
  { value: "marketing", label: "营销推广", description: "吸引人的营销消息" },
  { value: "followup", label: "客户跟进", description: "提高回复率的跟进消息" },
  { value: "greeting", label: "问候祝福", description: "首次接触或节日祝福" },
  { value: "promotion", label: "促销活动", description: "折扣限时优惠消息" },
  { value: "custom", label: "自定义", description: "按需生成任意文案" },
];

const TONES = [
  { value: "专业正式", label: "专业正式" },
  { value: "轻松友好", label: "轻松友好" },
  { value: "热情活力", label: "热情活力" },
  { value: "温馨感性", label: "温馨感性" },
  { value: "简洁直接", label: "简洁直接" },
];

const LANGUAGES = [
  { value: "中文", label: "中文" },
  { value: "英文", label: "English" },
  { value: "马来文", label: "Bahasa Melayu" },
  { value: "粤语", label: "粤语" },
];

const CATEGORY_LABELS: Record<Category, string> = {
  marketing: "营销推广",
  followup: "客户跟进",
  greeting: "问候祝福",
  promotion: "促销活动",
  custom: "自定义",
};

function CopyResultCard({
  text,
  index,
  onPolish,
}: {
  text: string;
  index: number;
  onPolish: (text: string) => void;
}) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    void navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <Card className="border-border/50 bg-card/60">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <Badge variant="secondary" className="text-xs">
          方案 {index + 1}
        </Badge>
        <div className="flex gap-2">
          <Button size="sm" variant="ghost" onClick={handleCopy} className="h-7 px-2 text-xs">
            <Copy className="h-3 w-3 mr-1" />
            {copied ? "已复制" : "复制"}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => onPolish(text)}
            className="h-7 px-2 text-xs"
          >
            <Wand2 className="h-3 w-3 mr-1" />
            润色
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm whitespace-pre-wrap leading-relaxed">{text}</p>
      </CardContent>
    </Card>
  );
}

function HistoryItem({
  item,
  onDelete,
}: {
  item: {
    _id: Id<"aiCopyHistory">;
    prompt: string;
    result: string;
    category: Category;
    createdAt: string;
  };
  onDelete: (id: Id<"aiCopyHistory">) => void;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="border border-border/40 rounded-lg p-3 space-y-2 bg-card/30">
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <Badge variant="outline" className="text-xs shrink-0">
              {CATEGORY_LABELS[item.category]}
            </Badge>
            <span className="text-xs text-muted-foreground truncate">
              {new Date(item.createdAt).toLocaleString("zh-CN", {
                month: "short",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit",
              })}
            </span>
          </div>
          <p className="text-xs text-muted-foreground line-clamp-1">{item.prompt}</p>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <Button
            size="sm"
            variant="ghost"
            className="h-6 w-6 p-0"
            onClick={() => setExpanded(!expanded)}
          >
            {expanded ? (
              <ChevronUp className="h-3 w-3" />
            ) : (
              <ChevronDown className="h-3 w-3" />
            )}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-6 w-6 p-0 text-destructive hover:text-destructive"
            onClick={() => onDelete(item._id)}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      </div>
      {expanded && (
        <p className="text-xs whitespace-pre-wrap leading-relaxed border-t border-border/40 pt-2 text-foreground/80">
          {item.result}
        </p>
      )}
    </div>
  );
}

export default function AiCopyPage() {
  const [prompt, setPrompt] = useState("");
  const [category, setCategory] = useState<Category>("marketing");
  const [tone, setTone] = useState("专业正式");
  const [language, setLanguage] = useState("中文");
  const [isGenerating, setIsGenerating] = useState(false);
  const [results, setResults] = useState<string[]>([]);

  // Polish panel
  const [polishText, setPolishText] = useState("");
  const [polishInstruction, setPolishInstruction] = useState("");
  const [isPolishing, setIsPolishing] = useState(false);
  const [polishedResult, setPolishedResult] = useState("");

  const generateCopy = useAction(api.aiCopyActions.generateCopy);
  const polishCopy = useAction(api.aiCopyActions.polishCopy);
  const saveToHistory = useMutation(api.aiCopy.saveToHistory);
  const deleteHistory = useMutation(api.aiCopy.deleteHistory);
  const history = useQuery(api.aiCopy.listHistory, {});

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error("请输入文案需求描述");
      return;
    }
    setIsGenerating(true);
    setResults([]);
    try {
      const res = await generateCopy({ prompt, category, tone, language });
      const parts = res.text
        .split(/\n?---\n?/)
        .map((s) => s.trim())
        .filter(Boolean);
      setResults(parts.length > 0 ? parts : [res.text]);

      // Save to history
      await saveToHistory({ prompt, result: res.text, category });
    } catch (err) {
      if (err instanceof ConvexError) {
        const data = err.data as { message: string };
        toast.error(data.message);
      } else {
        toast.error("生成失败，请稍后重试");
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePolishTrigger = (text: string) => {
    setPolishText(text);
    setPolishedResult("");
    setPolishInstruction("");
    window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
  };

  const handlePolish = async () => {
    if (!polishText.trim() || !polishInstruction.trim()) {
      toast.error("请填写润色内容和修改要求");
      return;
    }
    setIsPolishing(true);
    setPolishedResult("");
    try {
      const res = await polishCopy({ text: polishText, instruction: polishInstruction });
      setPolishedResult(res.text);
    } catch (err) {
      if (err instanceof ConvexError) {
        const data = err.data as { message: string };
        toast.error(data.message);
      } else {
        toast.error("润色失败，请稍后重试");
      }
    } finally {
      setIsPolishing(false);
    }
  };

  const handleDeleteHistory = async (id: Id<"aiCopyHistory">) => {
    try {
      await deleteHistory({ id });
      toast.success("已删除");
    } catch {
      toast.error("删除失败");
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Sparkles className="h-6 w-6 text-primary" />
          AI 文案助手
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          智能生成 WhatsApp 营销文案，一键复制直接使用
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Generator */}
        <div className="lg:col-span-2 space-y-5">
          {/* Category selector */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {CATEGORIES.map((c) => (
              <button
                key={c.value}
                onClick={() => setCategory(c.value)}
                className={`rounded-lg border p-3 text-left transition-all ${
                  category === c.value
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border/50 bg-card/40 hover:border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                <div className="font-medium text-xs">{c.label}</div>
                <div className="text-xs mt-0.5 opacity-70 hidden sm:block">{c.description}</div>
              </button>
            ))}
          </div>

          {/* Options row */}
          <div className="flex gap-3 flex-wrap">
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">语气风格</Label>
              <Select value={tone} onValueChange={setTone}>
                <SelectTrigger className="h-8 w-32 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TONES.map((t) => (
                    <SelectItem key={t.value} value={t.value} className="text-xs">
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">语言</Label>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="h-8 w-32 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map((l) => (
                    <SelectItem key={l.value} value={l.value} className="text-xs">
                      {l.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Prompt */}
          <div className="space-y-2">
            <Label>描述你的需求</Label>
            <Textarea
              placeholder={
                category === "marketing"
                  ? "例如：推广我们的新产品——健康奶茶，主打无糖低卡，目标客户是注重健康的年轻女性..."
                  : category === "followup"
                    ? "例如：跟进上周咨询过我们课程但还未报名的潜在客户..."
                    : category === "greeting"
                      ? "例如：农历新年给老客户发送新年祝福，顺带提醒他们春节优惠..."
                      : category === "promotion"
                        ? "例如：双十一活动，全场8折，限时48小时，主推护肤品套装..."
                        : "请描述你需要的文案内容、场景和要求..."
              }
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={4}
              className="resize-none"
            />
          </div>

          <Button
            onClick={() => void handleGenerate()}
            disabled={isGenerating || !prompt.trim()}
            className="w-full gap-2"
            size="lg"
          >
            {isGenerating ? (
              <>
                <Spinner className="h-4 w-4" />
                AI 生成中...
              </>
            ) : (
              <>
                <Send className="h-4 w-4" />
                生成文案
              </>
            )}
          </Button>

          {/* Results */}
          {isGenerating && (
            <div className="space-y-3">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-28 w-full" />
              ))}
            </div>
          )}

          {!isGenerating && results.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-sm font-semibold text-muted-foreground">
                生成结果 · {results.length} 条文案
              </h2>
              {results.map((text, i) => (
                <CopyResultCard key={i} text={text} index={i} onPolish={handlePolishTrigger} />
              ))}
            </div>
          )}

          {/* Polish panel */}
          {polishText && (
            <Card className="border-primary/30 bg-primary/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Wand2 className="h-4 w-4 text-primary" />
                  文案润色
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">原始文案</Label>
                  <Textarea
                    value={polishText}
                    onChange={(e) => setPolishText(e.target.value)}
                    rows={3}
                    className="text-sm resize-none"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">修改要求</Label>
                  <Textarea
                    placeholder="例如：语气更活泼一些，加入表情符号，突出折扣力度..."
                    value={polishInstruction}
                    onChange={(e) => setPolishInstruction(e.target.value)}
                    rows={2}
                    className="text-sm resize-none"
                  />
                </div>
                <Button
                  onClick={() => void handlePolish()}
                  disabled={isPolishing || !polishInstruction.trim()}
                  size="sm"
                  className="gap-2"
                >
                  {isPolishing ? <Spinner className="h-3 w-3" /> : <Wand2 className="h-3 w-3" />}
                  {isPolishing ? "润色中..." : "开始润色"}
                </Button>

                {isPolishing && <Skeleton className="h-24 w-full" />}

                {!isPolishing && polishedResult && (
                  <div className="rounded-lg bg-card border border-border/50 p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-primary">润色结果</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 px-2 text-xs"
                        onClick={() => {
                          void navigator.clipboard.writeText(polishedResult).then(() =>
                            toast.success("已复制")
                          );
                        }}
                      >
                        <Copy className="h-3 w-3 mr-1" />
                        复制
                      </Button>
                    </div>
                    <p className="text-sm whitespace-pre-wrap leading-relaxed">{polishedResult}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right: History */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <h2 className="text-sm font-semibold">生成历史</h2>
          </div>

          {history === undefined && (
            <div className="space-y-2">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          )}

          {history !== undefined && history.length === 0 && (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <Clock />
                </EmptyMedia>
                <EmptyTitle>暂无历史记录</EmptyTitle>
                <EmptyDescription>生成的文案将自动保存在这里</EmptyDescription>
              </EmptyHeader>
            </Empty>
          )}

          {history !== undefined && history.length > 0 && (
            <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
              {history.map((item) => (
                <HistoryItem
                  key={item._id}
                  item={item}
                  onDelete={(id) => void handleDeleteHistory(id)}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
