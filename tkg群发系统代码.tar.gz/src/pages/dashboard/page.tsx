import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import {
  Users,
  Send,
  Smartphone,
  Eye,
  MessageSquare,
  TrendingUp,
  Activity,
  CheckCircle2,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";

const STATUS_MAP: Record<string, { label: string; className: string }> = {
  draft: { label: "草稿", className: "bg-muted text-muted-foreground" },
  scheduled: { label: "已排程", className: "bg-blue-500/10 text-blue-400" },
  running: { label: "发送中", className: "bg-primary/10 text-primary" },
  paused: { label: "已暂停", className: "bg-yellow-500/10 text-yellow-400" },
  completed: { label: "已完成", className: "bg-primary/10 text-primary" },
  failed: { label: "失败", className: "bg-destructive/10 text-destructive" },
};

export default function DashboardHome() {
  const stats = useQuery(api.campaigns.getStats, {});

  if (stats === undefined) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">仪表盘</h1>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
      </div>
    );
  }

  const statCards = [
    { icon: Users, label: "总联系人", value: stats.totalContacts, color: "text-blue-400" },
    { icon: Smartphone, label: "已连接账号", value: `${stats.connectedAccounts}/${stats.totalAccounts}`, color: "text-primary" },
    { icon: Send, label: "总发送量", value: stats.totalSent.toLocaleString(), color: "text-violet-400" },
    { icon: CheckCircle2, label: "已送达", value: stats.totalDelivered.toLocaleString(), color: "text-primary" },
    { icon: Eye, label: "已读", value: stats.totalRead.toLocaleString(), color: "text-cyan-400" },
    { icon: MessageSquare, label: "已回复", value: stats.totalReplied.toLocaleString(), color: "text-yellow-400" },
    { icon: TrendingUp, label: "送达率", value: `${stats.deliveryRate}%`, color: "text-primary" },
    { icon: Activity, label: "活跃任务", value: stats.activeCampaigns, color: "text-orange-400" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">仪表盘</h1>
        <p className="text-muted-foreground text-sm mt-1">
          WhatsApp 营销系统概览
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="pt-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground font-medium">
                    {stat.label}
                  </p>
                  <p className="text-2xl font-bold mt-1">{stat.value}</p>
                </div>
                <div className={`size-10 rounded-xl bg-card flex items-center justify-center ${stat.color}`}>
                  <stat.icon className="size-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent campaigns */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">最近任务</CardTitle>
        </CardHeader>
        <CardContent>
          {stats.recentCampaigns.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">
              暂无群发任务，去创建第一个吧
            </p>
          ) : (
            <div className="space-y-3">
              {stats.recentCampaigns.map((campaign) => {
                const statusInfo = STATUS_MAP[campaign.status] ?? {
                  label: campaign.status,
                  className: "bg-muted text-muted-foreground",
                };
                return (
                  <div
                    key={campaign._id}
                    className="flex items-center justify-between py-2 border-b border-border/50 last:border-0"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate">
                        {campaign.name}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {campaign.totalRecipients} 收件人 · 已发送 {campaign.sentCount}
                      </p>
                    </div>
                    <Badge variant="secondary" className={statusInfo.className}>
                      {statusInfo.label}
                    </Badge>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
