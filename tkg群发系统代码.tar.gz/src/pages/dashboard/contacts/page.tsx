import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { useState } from "react";
import { Plus, Upload, Search, Trash2, Tag } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import { toast } from "sonner";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { ConvexError } from "convex/values";
import CsvImportDialog from "./_components/csv-import-dialog.tsx";

export default function ContactsPage() {
  const contacts = useQuery(api.contacts.list, {});
  const addContact = useMutation(api.contacts.add);
  const removeContact = useMutation(api.contacts.remove);
  const [search, setSearch] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);

  // Add contact form state
  const [newPhone, setNewPhone] = useState("");
  const [newName, setNewName] = useState("");
  const [newTags, setNewTags] = useState("");

  const handleAdd = async () => {
    if (!newPhone.trim()) {
      toast.error("请输入手机号");
      return;
    }
    try {
      await addContact({
        phone: newPhone.trim(),
        name: newName.trim() || undefined,
        tags: newTags
          .split(",")
          .map((t) => t.trim())
          .filter(Boolean),
      });
      toast.success("联系人已添加");
      setNewPhone("");
      setNewName("");
      setNewTags("");
      setAddOpen(false);
    } catch (e) {
      if (e instanceof ConvexError) {
        const data = e.data as { message: string };
        toast.error(data.message);
      } else {
        toast.error("添加失败");
      }
    }
  };

  const handleDelete = async (contactId: Id<"contacts">) => {
    try {
      await removeContact({ contactId });
      toast.success("已删除");
    } catch {
      toast.error("删除失败");
    }
  };

  const filtered = contacts?.filter((c) => {
    const q = search.toLowerCase();
    if (!q) return true;
    return (
      c.phone.includes(q) ||
      c.name?.toLowerCase().includes(q) ||
      c.tags.some((t) => t.toLowerCase().includes(q))
    );
  });

  if (contacts === undefined) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">联系人管理</h1>
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">联系人管理</h1>
          <p className="text-sm text-muted-foreground mt-1">
            共 {contacts.length} 个联系人
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* Import CSV wizard */}
          <Button variant="secondary" size="sm" className="gap-1.5" onClick={() => setImportOpen(true)}>
            <Upload className="size-4" />
            导入 CSV
          </Button>
          <CsvImportDialog open={importOpen} onOpenChange={setImportOpen} />

          {/* Add contact */}
          <Dialog open={addOpen} onOpenChange={setAddOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1.5">
                <Plus className="size-4" />
                添加
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>添加联系人</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>手机号 *</Label>
                  <Input
                    placeholder="+8613800138000"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                  />
                </div>
                <div>
                  <Label>姓名</Label>
                  <Input
                    placeholder="张三"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                  />
                </div>
                <div>
                  <Label>标签（逗号分隔）</Label>
                  <Input
                    placeholder="VIP, 新客户, 跨境"
                    value={newTags}
                    onChange={(e) => setNewTags(e.target.value)}
                  />
                </div>
                <Button className="w-full" onClick={handleAdd}>
                  添加联系人
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
        <Input
          placeholder="搜索号码、姓名或标签..."
          className="pl-9"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* List */}
      {filtered && filtered.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Tag />
            </EmptyMedia>
            <EmptyTitle>
              {search ? "没有匹配的联系人" : "暂无联系人"}
            </EmptyTitle>
            <EmptyDescription>
              {search
                ? "尝试其他关键词"
                : "点击添加或导入CSV开始管理你的联系人"}
            </EmptyDescription>
          </EmptyHeader>
          {!search && (
            <EmptyContent>
              <Button size="sm" onClick={() => setAddOpen(true)}>
                <Plus className="size-4 mr-1" />
                添加联系人
              </Button>
            </EmptyContent>
          )}
        </Empty>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {filtered?.map((contact) => (
                <div
                  key={contact._id}
                  className="flex items-center justify-between px-4 py-3 hover:bg-accent/50 transition-colors"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium">
                        {contact.name || contact.phone}
                      </p>
                      {contact.name && (
                        <span className="text-xs text-muted-foreground font-mono">
                          {contact.phone}
                        </span>
                      )}
                    </div>
                    {contact.tags.length > 0 && (
                      <div className="flex items-center gap-1 mt-1 flex-wrap">
                        {contact.tags.map((tag) => (
                          <Badge
                            key={tag}
                            variant="secondary"
                            className="text-[10px] px-1.5 py-0"
                          >
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    onClick={() => handleDelete(contact._id)}
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
