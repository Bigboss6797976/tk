/**
 * Robust CSV parser that handles:
 * - Quoted fields with commas inside
 * - Quoted fields with embedded newlines
 * - Various line endings (CRLF, LF)
 * - BOM stripping
 */
export function parseCsv(raw: string): string[][] {
  // Strip BOM
  const text = raw.startsWith("\uFEFF") ? raw.slice(1) : raw;

  const rows: string[][] = [];
  let col = "";
  let row: string[] = [];
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];

    if (inQuotes) {
      if (ch === '"' && next === '"') {
        // Escaped quote
        col += '"';
        i++;
      } else if (ch === '"') {
        inQuotes = false;
      } else {
        col += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === ",") {
        row.push(col.trim());
        col = "";
      } else if (ch === "\r" && next === "\n") {
        row.push(col.trim());
        rows.push(row);
        row = [];
        col = "";
        i++;
      } else if (ch === "\n" || ch === "\r") {
        row.push(col.trim());
        rows.push(row);
        row = [];
        col = "";
      } else {
        col += ch;
      }
    }
  }

  // Push last field / row
  if (col || row.length > 0) {
    row.push(col.trim());
    rows.push(row);
  }

  return rows.filter((r) => r.some((c) => c.length > 0));
}

export type ParsedRow = {
  phone: string;
  name: string;
  tags: string[];
  variables: Record<string, string>;
  valid: boolean;
  error?: string;
};

export type ColumnMapping = {
  phoneCol: number | null;
  nameCol: number | null;
  tagsCol: number | null;
  /** Extra columns to import as variables: col index -> variable key */
  extraCols: { index: number; key: string }[];
};

const PHONE_RE = /^[+\d][\d\s\-().]{5,19}$/;

export function applyMapping(rows: string[][], mapping: ColumnMapping): ParsedRow[] {
  return rows.map((cols) => {
    const phone =
      mapping.phoneCol !== null ? (cols[mapping.phoneCol] ?? "").replace(/\s+/g, "") : "";

    const name = mapping.nameCol !== null ? (cols[mapping.nameCol] ?? "") : "";

    const rawTags = mapping.tagsCol !== null ? (cols[mapping.tagsCol] ?? "") : "";
    const tags = rawTags
      .split(/[;，,]/)
      .map((t) => t.trim())
      .filter(Boolean);

    const variables: Record<string, string> = {};
    for (const extra of mapping.extraCols) {
      const val = cols[extra.index] ?? "";
      if (val) variables[extra.key] = val;
    }

    let valid = true;
    let error: string | undefined;

    if (!phone) {
      valid = false;
      error = "手机号为空";
    } else if (!PHONE_RE.test(phone)) {
      valid = false;
      error = "手机号格式不正确";
    }

    return { phone, name, tags, variables, valid, error };
  });
}

/** Guess column mapping from header row */
export function guessMapping(headers: string[]): ColumnMapping {
  let phoneCol: number | null = null;
  let nameCol: number | null = null;
  let tagsCol: number | null = null;

  headers.forEach((h, i) => {
    const lower = h.toLowerCase();
    if (phoneCol === null && /phone|手机|号码|mobile|tel|电话/.test(lower)) {
      phoneCol = i;
    } else if (nameCol === null && /name|姓名|名字|称呼/.test(lower)) {
      nameCol = i;
    } else if (tagsCol === null && /tag|标签|group|分组/.test(lower)) {
      tagsCol = i;
    }
  });

  return { phoneCol, nameCol, tagsCol, extraCols: [] };
}

export const SAMPLE_CSV = `phone,name,tags,remark
+60123456789,张三,VIP;新客户,
+60198765432,李四,普通客户,
+6011-2345678,王五,VIP,重要
`;
