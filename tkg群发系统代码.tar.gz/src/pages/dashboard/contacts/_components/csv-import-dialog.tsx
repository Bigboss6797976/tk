import { useState, useCallback, useRef } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import {
  Upload,
  FileText,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Download,
  ChevronRight,
  RefreshCw,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { cn } from "@/lib/utils.ts";
import {
  parseCsv,
  applyMapping,
  guessMapping,
  SAMPLE_CSV,
  type ParsedRow,
  type ColumnMapping,
} from "../_lib/csv-parser.ts";

type Step = "upload" | "map" | "preview" | "result";

type ImportResult = { imported: number; skipped: number };

const NONE = "__none__";

function StepIndicator({ current }: { current: Step }) {
  const steps: { id: Step; label: string }[] = [
    { id: "upload", label: "上传文件" },
    { id: "map", label: "列映射" },
    { id: "preview", label: "预览确认" },
    { id: "result", label: "导入结果" },
  ];
  const idx = steps.findIndex((s) => s.id === current);
  return (
    <div className="flex items-center gap-1 mb-6">
      {steps.map((s, i) => (
        <div key={s.id} className="flex items-center gap-1">
          <div
            className={cn(
              "flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium transition-colors",
              i < idx
                ? "bg-primary/20 text-primary"
                : i === idx
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground"
            )}
          >
            {i < idx ? (
              <CheckCircle2 className="h-3 w-3" />
            ) : (
              <span className="w-3 h-3 rounded-full border border-current flex items-center justify-center text-[9px]">
                {i + 1}
              </span>
            )}
            {s.label}
          </div>
          {i < steps.length - 1 && (
            <ChevronRight className="h-3 w-3 text-muted-foreground shrink-0" />
          )}
        </div>
      ))}
    </div>
  );
}

/* ─── Step 1: Upload ─── */
function UploadStep({
  onParsed,
}: {
  onParsed: (headers: string[], dataRows: string[][], fileName: string) => void;
}) {
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const processFile = useCallback(
    async (file: File) => {
      setError(null);
      if (!file.name.match(/\.(csv|txt)$/i)) {
        setError("请上传 .csv 或 .txt 文件");
        return;
      }
      const text = await file.text();
      const rows = parseCsv(text);
      if (rows.length < 2) {
        setError("文件内容为空或格式不正确，需至少包含标题行和一行数据");
        return;
      }
      onParsed(rows[0], rows.slice(1), file.name);
    },
    [onParsed]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragging(false);
      const file = e.dataTransfer.files[0];
      if (file) void processFile(file);
    },
    [processFile]
  );

  const handleDownloadSample = () => {
    const blob = new Blob([SAMPLE_CSV], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "联系人模板.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
        className={cn(
          "border-2 border-dashed rounded-xl p-10 flex flex-col items-center justify-center gap-3 cursor-pointer transition-all",
          dragging
            ? "border-primary bg-primary/10"
            : "border-border/60 hover:border-primary/50 hover:bg-muted/30"
        )}
      >
        <div className="p-3 rounded-full bg-muted">
          <Upload className="h-6 w-6 text-muted-foreground" />
        </div>
        <div className="text-center">
          <p className="font-medium text-sm">拖放 CSV 文件到这里</p>
          <p className="text-xs text-muted-foreground mt-1">或点击选择文件 (.csv / .txt)</p>
        </div>
        <input
          ref={inputRef}
          type="file"
          accept=".csv,.txt"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void processFile(file);
            e.target.value = "";
          }}
        />
      </div>

      {error && (
        <div className="flex items-center gap-2 text-destructive text-sm bg-destructive/10 rounded-lg px-3 py-2">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}

      <div className="rounded-lg bg-muted/30 border border-border/40 p-4 space-y-2">
        <p className="text-xs font-medium text-muted-foreground">CSV 格式说明</p>
        <p className="text-xs text-muted-foreground">
          需包含 <strong className="text-foreground">phone / 手机 / 号码</strong> 列（必填），可选列：
          name/姓名、tags/标签（分号分隔多个标签）及任意自定义变量列。
        </p>
        <Button
          size="sm"
          variant="secondary"
          className="gap-1.5 h-7 text-xs"
          onClick={(e) => { e.stopPropagation(); handleDownloadSample(); }}
        >
          <Download className="h-3 w-3" />
          下载模板
        </Button>
      </div>
    </div>
  );
}

/* ─── Step 2: Column Mapping ─── */
function MapStep({
  headers,
  dataRows,
  fileName,
  onNext,
  onBack,
}: {
  headers: string[];
  dataRows: string[][];
  fileName: string;
  onNext: (mapping: ColumnMapping) => void;
  onBack: () => void;
}) {
  const initial = guessMapping(headers);
  const [phoneCol, setPhoneCol] = useState<number | null>(initial.phoneCol);
  const [nameCol, setNameCol] = useState<number | null>(initial.nameCol);
  const [tagsCol, setTagsCol] = useState<number | null>(initial.tagsCol);

  const preview = dataRows.slice(0, 3);

  const colOptions = headers.map((h, i) => ({ label: h || `列 ${i + 1}`, value: i }));

  const toNum = (v: string) => (v === NONE ? null : Number(v));

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <FileText className="h-4 w-4 shrink-0" />
        <span className="truncate">{fileName}</span>
        <Badge variant="secondary" className="text-xs shrink-0">
          {dataRows.length} 行数据
        </Badge>
      </div>

      {/* Mapping selectors */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { label: "手机号 *", value: phoneCol, set: (v: string) => setPhoneCol(toNum(v)), required: true },
          { label: "姓名", value: nameCol, set: (v: string) => setNameCol(toNum(v)), required: false },
          { label: "标签", value: tagsCol, set: (v: string) => setTagsCol(toNum(v)), required: false },
        ].map(({ label, value, set, required }) => (
          <div key={label} className="space-y-1.5">
            <label className="text-xs text-muted-foreground">{label}</label>
            <Select
              value={value === null ? NONE : String(value)}
              onValueChange={set}
            >
              <SelectTrigger className="h-8 text-xs">
                <SelectValue placeholder="选择列" />
              </SelectTrigger>
              <SelectContent>
                {!required && (
                  <SelectItem value={NONE} className="text-xs text-muted-foreground">
                    — 不导入 —
                  </SelectItem>
                )}
                {colOptions.map((o) => (
                  <SelectItem key={o.value} value={String(o.value)} className="text-xs">
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        ))}
      </div>

      {/* Mini preview table */}
      <div className="overflow-x-auto rounded-lg border border-border/40">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-border/40 bg-muted/30">
              {headers.map((h, i) => (
                <th
                  key={i}
                  className={cn(
                    "px-3 py-2 text-left font-medium",
                    i === phoneCol
                      ? "text-primary"
                      : i === nameCol
                        ? "text-blue-400"
                        : i === tagsCol
                          ? "text-yellow-400"
                          : "text-muted-foreground"
                  )}
                >
                  {h || `列 ${i + 1}`}
                  {i === phoneCol && <span className="ml-1 text-[9px]">📞</span>}
                  {i === nameCol && <span className="ml-1 text-[9px]">👤</span>}
                  {i === tagsCol && <span className="ml-1 text-[9px]">🏷️</span>}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {preview.map((row, ri) => (
              <tr key={ri} className="border-b border-border/20 hover:bg-muted/20">
                {headers.map((_, ci) => (
                  <td key={ci} className="px-3 py-1.5 text-muted-foreground truncate max-w-[120px]">
                    {row[ci] ?? ""}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex gap-2 justify-end">
        <Button variant="secondary" size="sm" onClick={onBack}>
          上一步
        </Button>
        <Button
          size="sm"
          disabled={phoneCol === null}
          onClick={() => onNext({ phoneCol, nameCol, tagsCol, extraCols: [] })}
        >
          下一步：预览
        </Button>
      </div>
    </div>
  );
}

/* ─── Step 3: Preview ─── */
function PreviewStep({
  rows,
  onImport,
  onBack,
  importing,
}: {
  rows: ParsedRow[];
  onImport: () => void;
  onBack: () => void;
  importing: boolean;
}) {
  const valid = rows.filter((r) => r.valid);
  const invalid = rows.filter((r) => !r.valid);
  const preview = rows.slice(0, 50);

  return (
    <div className="space-y-4">
      {/* Summary bar */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-1.5 text-sm">
          <CheckCircle2 className="h-4 w-4 text-green-400" />
          <span className="font-medium">{valid.length}</span>
          <span className="text-muted-foreground">条有效</span>
        </div>
        {invalid.length > 0 && (
          <div className="flex items-center gap-1.5 text-sm">
            <XCircle className="h-4 w-4 text-destructive" />
            <span className="font-medium">{invalid.length}</span>
            <span className="text-muted-foreground">条无效（将跳过）</span>
          </div>
        )}
        {rows.length > 50 && (
          <span className="text-xs text-muted-foreground">仅展示前 50 行</span>
        )}
      </div>

      {/* Preview table */}
      <div className="overflow-auto max-h-72 rounded-lg border border-border/40">
        <table className="w-full text-xs">
          <thead className="sticky top-0 bg-card z-10">
            <tr className="border-b border-border/40">
              <th className="px-3 py-2 text-left font-medium text-muted-foreground w-6">#</th>
              <th className="px-3 py-2 text-left font-medium text-muted-foreground">手机号</th>
              <th className="px-3 py-2 text-left font-medium text-muted-foreground">姓名</th>
              <th className="px-3 py-2 text-left font-medium text-muted-foreground">标签</th>
              <th className="px-3 py-2 text-left font-medium text-muted-foreground">状态</th>
            </tr>
          </thead>
          <tbody>
            {preview.map((row, i) => (
              <tr
                key={i}
                className={cn(
                  "border-b border-border/20",
                  row.valid ? "hover:bg-muted/20" : "bg-destructive/5"
                )}
              >
                <td className="px-3 py-1.5 text-muted-foreground">{i + 1}</td>
                <td className="px-3 py-1.5 font-mono">{row.phone || "—"}</td>
                <td className="px-3 py-1.5 text-muted-foreground">{row.name || "—"}</td>
                <td className="px-3 py-1.5">
                  <div className="flex gap-1 flex-wrap">
                    {row.tags.length > 0
                      ? row.tags.map((t: string) => (
                          <Badge key={t} variant="secondary" className="text-[10px] h-4 px-1">
                            {t}
                          </Badge>
                        ))
                      : <span className="text-muted-foreground">—</span>}
                  </div>
                </td>
                <td className="px-3 py-1.5">
                  {row.valid ? (
                    <CheckCircle2 className="h-3.5 w-3.5 text-green-400" />
                  ) : (
                    <div className="flex items-center gap-1 text-destructive">
                      <XCircle className="h-3.5 w-3.5 shrink-0" />
                      <span className="text-[10px]">{row.error}</span>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {valid.length === 0 && (
        <div className="flex items-center gap-2 text-destructive text-sm bg-destructive/10 rounded-lg px-3 py-2">
          <AlertCircle className="h-4 w-4 shrink-0" />
          没有有效数据可导入，请检查列映射或文件内容
        </div>
      )}

      <div className="flex gap-2 justify-end">
        <Button variant="secondary" size="sm" onClick={onBack} disabled={importing}>
          上一步
        </Button>
        <Button
          size="sm"
          disabled={valid.length === 0 || importing}
          onClick={onImport}
          className="gap-1.5"
        >
          {importing ? (
            <>
              <Spinner className="h-3.5 w-3.5" />
              导入中...
            </>
          ) : (
            <>确认导入 {valid.length} 条</>
          )}
        </Button>
      </div>
    </div>
  );
}

/* ─── Step 4: Result ─── */
function ResultStep({
  result,
  total,
  onClose,
  onImportMore,
}: {
  result: ImportResult;
  total: number;
  onClose: () => void;
  onImportMore: () => void;
}) {
  return (
    <div className="flex flex-col items-center gap-5 py-4">
      <div className="p-4 rounded-full bg-green-400/15">
        <CheckCircle2 className="h-10 w-10 text-green-400" />
      </div>
      <div className="text-center space-y-1">
        <p className="text-lg font-bold">导入完成</p>
        <p className="text-sm text-muted-foreground">
          共处理 <strong className="text-foreground">{total}</strong> 条记录
        </p>
      </div>
      <div className="flex gap-4">
        <div className="text-center">
          <p className="text-3xl font-bold text-green-400">{result.imported}</p>
          <p className="text-xs text-muted-foreground mt-0.5">成功导入</p>
        </div>
        <div className="w-px bg-border" />
        <div className="text-center">
          <p className="text-3xl font-bold text-muted-foreground">{result.skipped}</p>
          <p className="text-xs text-muted-foreground mt-0.5">跳过（重复）</p>
        </div>
      </div>
      <div className="flex gap-2">
        <Button variant="secondary" size="sm" className="gap-1.5" onClick={onImportMore}>
          <RefreshCw className="h-3.5 w-3.5" />
          继续导入
        </Button>
        <Button size="sm" onClick={onClose}>
          完成
        </Button>
      </div>
    </div>
  );
}

/* ─── Main wizard ─── */
export default function CsvImportDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const bulkImport = useMutation(api.contacts.bulkImport);

  const [step, setStep] = useState<Step>("upload");
  const [headers, setHeaders] = useState<string[]>([]);
  const [dataRows, setDataRows] = useState<string[][]>([]);
  const [fileName, setFileName] = useState("");
  const [mapping, setMapping] = useState<ColumnMapping>({
    phoneCol: null,
    nameCol: null,
    tagsCol: null,
    extraCols: [],
  });
  const [parsedRows, setParsedRows] = useState<ParsedRow[]>([]);
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);

  const reset = () => {
    setStep("upload");
    setHeaders([]);
    setDataRows([]);
    setFileName("");
    setMapping({ phoneCol: null, nameCol: null, tagsCol: null, extraCols: [] });
    setParsedRows([]);
    setImporting(false);
    setResult(null);
  };

  const handleParsed = (h: string[], rows: string[][], name: string) => {
    setHeaders(h);
    setDataRows(rows);
    setFileName(name);
    setStep("map");
  };

  const handleMapping = (m: ColumnMapping) => {
    setMapping(m);
    const rows = applyMapping(dataRows, m);
    setParsedRows(rows);
    setStep("preview");
  };

  const handleImport = async () => {
    const validRows = parsedRows.filter((r) => r.valid);
    setImporting(true);
    try {
      const res = await bulkImport({
        contacts: validRows.map((r) => ({
          phone: r.phone,
          name: r.name || undefined,
          tags: r.tags,
          variables: Object.keys(r.variables).length > 0 ? r.variables : undefined,
        })),
      });
      setResult(res);
      setStep("result");
      toast.success(`成功导入 ${res.imported} 个联系人`);
    } catch (err) {
      if (err instanceof ConvexError) {
        const data = err.data as { message: string };
        toast.error(data.message);
      } else {
        toast.error("导入失败，请重试");
      }
    } finally {
      setImporting(false);
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    setTimeout(reset, 300);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) handleClose(); }}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>批量导入联系人</DialogTitle>
        </DialogHeader>
        <StepIndicator current={step} />
        {step === "upload" && <UploadStep onParsed={handleParsed} />}
        {step === "map" && (
          <MapStep
            headers={headers}
            dataRows={dataRows}
            fileName={fileName}
            onNext={handleMapping}
            onBack={() => setStep("upload")}
          />
        )}
        {step === "preview" && (
          <PreviewStep
            rows={parsedRows}
            onImport={() => void handleImport()}
            onBack={() => setStep("map")}
            importing={importing}
          />
        )}
        {step === "result" && result && (
          <ResultStep
            result={result}
            total={parsedRows.filter((r) => r.valid).length}
            onClose={handleClose}
            onImportMore={reset}
          />
        )}
      </DialogContent>
    </Dialog>
  );
}
