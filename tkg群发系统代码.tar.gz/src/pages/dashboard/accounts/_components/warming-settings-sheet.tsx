import { useState, useEffect } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import {
  Flame,
  Timer,
  TrendingUp,
  BarChart3,
  Coffee,
  Layers,
  AlertTriangle,
  CheckCircle2,
} from "lucide-react";
import { cn } from "@/lib/utils.ts";
import { differenceInDays } from "date-fns";

type Account = Doc<"accounts">;

type Props = {
  account: Account | null;
  open: boolean;
  onClose: () => void;
};

function NumInput({
  label,
  value,
  onChange,
  min,
  max,
  unit,
  icon: Icon,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  unit?: string;
  icon?: React.ElementType;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="flex items-center gap-1.5 text-sm">
        {Icon && <Icon className="size-3.5 text-muted-foreground" />}
        {label}
        {unit && <span className="text-muted-foreground font-normal">（{unit}）</span>}
      </Label>
      <Input
        type="number"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-9 text-sm"
      />
    </div>
  );
}

export default function WarmingSettingsSheet({ account, open, onClose }: Props) {
  const updateWarming = useMutation(api.accounts.updateWarmingSettings);
  const [saving, setSaving] = useState(false);

  // Form state with defaults
  const [enabled, setEnabled] = useState(false);
  const [warmingDays, setWarmingDays] = useState(30);
  const [startCount, setStartCount] = useState(20);
  const [increment, setIncrement] = useState(10);
  const [intervalMin, setIntervalMin] = useState(5);
  const [intervalMax, setIntervalMax] = useState(15);
  const [breakMin, setBreakMin] = useState(10);
  const [breakMax, setBreakMax] = useState(30);
  const [batchSize, setBatchSize] = useState(50);

  // Populate from account
  useEffect(() => {
    if (!account) return;
    setEnabled(account.warmingEnabled ?? false);
    setWarmingDays(account.warmingDays ?? 30);
    setStartCount(account.warmingStartCount ?? 20);
    setIncrement(account.warmingIncrement ?? 10);
    setIntervalMin(account.sendIntervalMin ?? 5);
    setIntervalMax(account.sendIntervalMax ?? 15);
    setBreakMin(account.sessionBreakMin ?? 10);
    setBreakMax(account.sessionBreakMax ?? 30);
    setBatchSize(account.batchSize ?? 50);
  }, [account]);

  // Derived: estimated day limit
  const todayLimit = enabled
    ? Math.min(startCount + increment * currentDay(), account?.dailySendLimit ?? 9999)
    : (account?.dailySendLimit ?? 0);

  function currentDay() {
    if (!account?.warmingStartedAt) return 0;
    return Math.max(0, differenceInDays(new Date(), new Date(account.warmingStartedAt)));
  }

  const warmingProgress = account?.warmingStartedAt
    ? Math.min(100, Math.round((currentDay() / warmingDays) * 100))
    : 0;

  const handleSave = async () => {
    if (!account) return;
    if (intervalMin >= intervalMax) {
      toast.error("最小间隔必须小于最大间隔");
      return;
    }
    if (breakMin >= breakMax) {
      toast.error("休息最小时间必须小于最大时间");
      return;
    }
    setSaving(true);
    try {
      await updateWarming({
        accountId: account._id,
        warmingEnabled: enabled,
        warmingDays,
        warmingStartCount: startCount,
        warmingIncrement: increment,
        sendIntervalMin: intervalMin,
        sendIntervalMax: intervalMax,
        sessionBreakMin: breakMin,
        sessionBreakMax: breakMax,
        batchSize,
      });
      toast.success("养号设置已保存");
      onClose();
    } catch (err) {
      if (err instanceof ConvexError) {
        const { message } = err.data as { message: string };
        toast.error(message);
      } else {
        toast.error("保存失败");
      }
    } finally {
      setSaving(false);
    }
  };

  if (!account) return null;

  return (
    <Sheet open={open} onOpenChange={(v) => !v && onClose()}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
        <SheetHeader className="pb-2">
          <SheetTitle className="flex items-center gap-2">
            <Flame className="size-5 text-orange-400" />
            养号 & 限速设置
          </SheetTitle>
          <SheetDescription>
            {account.name} · {account.phone}
          </SheetDescription>
        </SheetHeader>

        <div className="space-y-6 pt-4">
          {/* Warming toggle */}
          <div className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/30">
            <div>
              <p className="text-sm font-semibold flex items-center gap-2">
                <Flame className="size-4 text-orange-400" />
                启用养号模式
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                自动从低量逐步提升每日发送量，降低封号风险
              </p>
            </div>
            <Switch checked={enabled} onCheckedChange={setEnabled} />
          </div>

          {/* Warming progress (if already started) */}
          {enabled && account.warmingStartedAt && (
            <div className="p-4 rounded-xl border border-orange-200 bg-orange-50 dark:bg-orange-950/20 dark:border-orange-800 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-orange-700 dark:text-orange-400 flex items-center gap-1.5">
                  <CheckCircle2 className="size-4" />
                  养号进行中
                </span>
                <Badge className="bg-orange-100 text-orange-700 border-orange-200 dark:bg-orange-900 dark:text-orange-300">
                  第 {currentDay()} / {warmingDays} 天
                </Badge>
              </div>
              <div className="h-2 rounded-full bg-orange-100 dark:bg-orange-900 overflow-hidden">
                <div
                  className="h-full rounded-full bg-orange-400 transition-all"
                  style={{ width: `${warmingProgress}%` }}
                />
              </div>
              <p className="text-xs text-orange-600 dark:text-orange-400">
                今日预计可发：<strong>{todayLimit}</strong> 条
              </p>
            </div>
          )}

          <Separator />

          {/* Warming plan */}
          <div className="space-y-4">
            <p className="text-sm font-semibold flex items-center gap-2">
              <TrendingUp className="size-4 text-primary" />
              养号计划
            </p>
            <div className="grid grid-cols-2 gap-3">
              <NumInput
                label="养号周期"
                value={warmingDays}
                onChange={setWarmingDays}
                min={7}
                max={90}
                unit="天"
                icon={BarChart3}
              />
              <NumInput
                label="起始每日发送量"
                value={startCount}
                onChange={setStartCount}
                min={1}
                unit="条"
                icon={TrendingUp}
              />
              <NumInput
                label="每日递增量"
                value={increment}
                onChange={setIncrement}
                min={1}
                unit="条"
                icon={TrendingUp}
              />
              <div className="space-y-1.5">
                <Label className="text-sm text-muted-foreground">第 30 天预计</Label>
                <div className="h-9 flex items-center px-3 rounded-md border border-border bg-muted text-sm font-semibold text-primary">
                  {Math.min(startCount + increment * 29, account.dailySendLimit)} 条/天
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Send interval */}
          <div className="space-y-4">
            <p className="text-sm font-semibold flex items-center gap-2">
              <Timer className="size-4 text-primary" />
              发送间隔（随机）
            </p>
            <div className="grid grid-cols-2 gap-3">
              <NumInput
                label="最小间隔"
                value={intervalMin}
                onChange={setIntervalMin}
                min={1}
                unit="秒"
                icon={Timer}
              />
              <NumInput
                label="最大间隔"
                value={intervalMax}
                onChange={setIntervalMax}
                min={intervalMin + 1}
                unit="秒"
                icon={Timer}
              />
            </div>
            {intervalMin >= intervalMax && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <AlertTriangle className="size-3" /> 最小间隔必须小于最大间隔
              </p>
            )}
          </div>

          <Separator />

          {/* Batch settings */}
          <div className="space-y-4">
            <p className="text-sm font-semibold flex items-center gap-2">
              <Layers className="size-4 text-primary" />
              批次设置
            </p>
            <NumInput
              label="每批发送数量"
              value={batchSize}
              onChange={setBatchSize}
              min={1}
              max={500}
              unit="条"
              icon={Layers}
            />
            <div className="grid grid-cols-2 gap-3">
              <NumInput
                label="批次间最短休息"
                value={breakMin}
                onChange={setBreakMin}
                min={1}
                unit="分钟"
                icon={Coffee}
              />
              <NumInput
                label="批次间最长休息"
                value={breakMax}
                onChange={setBreakMax}
                min={breakMin + 1}
                unit="分钟"
                icon={Coffee}
              />
            </div>
          </div>

          {/* Risk tips */}
          <div className={cn(
            "p-3 rounded-xl border text-xs space-y-1",
            enabled
              ? "bg-green-50 border-green-200 text-green-700 dark:bg-green-950/20 dark:border-green-800 dark:text-green-400"
              : "bg-muted border-border text-muted-foreground"
          )}>
            <p className="font-semibold">
              {enabled ? "✓ 已开启智能养号保护" : "养号建议"}
            </p>
            <p>• 新号建议起始 20 条，每天递增 10 条，持续 30 天</p>
            <p>• 发送间隔建议 5–15 秒，避免机器特征</p>
            <p>• 每 50 条后休息 10–30 分钟效果最佳</p>
          </div>

          <div className="flex gap-2 pt-2">
            <Button variant="ghost" className="flex-1" onClick={onClose}>取消</Button>
            <Button className="flex-1" onClick={handleSave} disabled={saving}>
              {saving ? "保存中..." : "保存设置"}
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
