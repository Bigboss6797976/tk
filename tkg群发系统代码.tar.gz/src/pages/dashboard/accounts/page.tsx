import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { useState } from "react";
import {
  Plus,
  Smartphone,
  Trash2,
  Wifi,
  WifiOff,
  Loader2,
  Flame,
  Settings2,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import type { Id, Doc } from "@/convex/_generated/dataModel.d.ts";
import WarmingSettingsSheet from "./_components/warming-settings-sheet.tsx";

const STATUS_MAP: Record<string, { icon: typeof Wifi; label: string; className: string }> = {
  connected: { icon: Wifi, label: "已连接", className: "bg-primary/10 text-primary" },
  disconnected: { icon: WifiOff, label: "未连接", className: "bg-muted text-muted-foreground" },
  warming: { icon: Loader2, label: "养号中", className: "bg-orange-500/10 text-orange-400" },
};

export default function AccountsPage() {
  const accounts = useQuery(api.accounts.list, {});
  const addAccount = useMutation(api.accounts.add);
  const updateStatus = useMutation(api.accounts.updateStatus);
  const removeAccount = useMutation(api.accounts.remove);

  const [addOpen, setAddOpen] = useState(false);
  const [warmingAccount, setWarmingAccount] = useState<Doc<"accounts"> | null>(null);

  // Form state
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [engine, setEngine] = useState<"cloud_api" | "baileys">("baileys");
  const [limit, setLimit] = useState("5000");

  const handleAdd = async () => {
    if (!name.trim() || !phone.trim()) {
      toast.error("请填写账号名称和手机号");
      return;
    }
    try {
      await addAccount({
        name: name.trim(),
        phone: phone.trim(),
        engine,
        dailySendLimit: parseInt(limit) || 5000,
      });
      toast.success("账号已添加");
      setName("");
      setPhone("");
      setEngine("baileys");
      setLimit("5000");
      setAddOpen(false);
    } catch (e) {
      if (e instanceof ConvexError) {
        const data = e.data as { message: string };
        toast.error(data.message);
      } else {
        toast.error("添加失败");
      }
    }
  };

  const handleToggleConnect = async (accountId: Id<"accounts">, currentStatus: string) => {
    const newStatus = currentStatus === "connected" ? "disconnected" as const : "connected" as const;
    try {
      await updateStatus({ accountId, status: newStatus });
      toast.success(newStatus === "connected" ? "已连接" : "已断开");
    } catch {
      toast.error("操作失败");
    }
  };

  const handleDelete = async (accountId: Id<"accounts">) => {
    try {
      await removeAccount({ accountId });
      toast.success("已删除");
      if (warmingAccount?._id === accountId) setWarmingAccount(null);
    } catch {
      toast.error("删除失败");
    }
  };

  if (accounts === undefined) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">账号管理</h1>
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">账号管理</h1>
          <p className="text-sm text-muted-foreground mt-1">
            管理你的 WhatsApp 账号与养号策略
          </p>
        </div>
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1.5">
              <Plus className="size-4" />
              添加账号
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>添加 WhatsApp 账号</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>账号名称 *</Label>
                <Input
                  placeholder="例：主号 01"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div>
                <Label>手机号 *</Label>
                <Input
                  placeholder="+8613800138000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>
              <div>
                <Label>引擎类型</Label>
                <Select value={engine} onValueChange={(v) => setEngine(v as "cloud_api" | "baileys")}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="baileys">Baileys 增强引擎</SelectItem>
                    <SelectItem value="cloud_api">官方 Cloud API</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>每日发送上限</Label>
                <Input
                  type="number"
                  value={limit}
                  onChange={(e) => setLimit(e.target.value)}
                />
              </div>
              <Button className="w-full" onClick={handleAdd}>
                添加账号
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {accounts.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Smartphone />
            </EmptyMedia>
            <EmptyTitle>暂无账号</EmptyTitle>
            <EmptyDescription>
              添加你的 WhatsApp 账号来开始群发
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button size="sm" onClick={() => setAddOpen(true)}>
              <Plus className="size-4 mr-1" />
              添加账号
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {accounts.map((account) => {
            const statusInfo = STATUS_MAP[account.status] ?? STATUS_MAP.disconnected;
            const StatusIcon = statusInfo.icon;
            const usagePercent =
              account.dailySendLimit > 0
                ? Math.min(
                    Math.round((account.sentToday / account.dailySendLimit) * 100),
                    100
                  )
                : 0;

            return (
              <Card key={account._id} className="relative">
                {account.warmingEnabled && (
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-orange-500/10 text-orange-500 border-orange-300 text-[10px] gap-1 px-1.5">
                      <Flame className="size-2.5" />
                      养号中
                    </Badge>
                  </div>
                )}
                <CardContent className="pt-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0 pr-16">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-semibold text-sm truncate">
                          {account.name}
                        </h3>
                        <Badge variant="secondary" className={statusInfo.className}>
                          <StatusIcon className={`size-3 mr-1 ${account.status === "warming" ? "animate-spin" : ""}`} />
                          {statusInfo.label}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1 font-mono">
                        {account.phone}
                      </p>
                      <div className="flex items-center gap-2 mt-2 flex-wrap">
                        <Badge variant="secondary" className="text-[10px]">
                          {account.engine === "cloud_api" ? "Cloud API" : "Baileys"}
                        </Badge>
                        <span className="text-[10px] text-muted-foreground">
                          今日 {account.sentToday}/{account.dailySendLimit}
                        </span>
                        {account.sendIntervalMin && (
                          <span className="text-[10px] text-muted-foreground">
                            间隔 {account.sendIntervalMin}–{account.sendIntervalMax}s
                          </span>
                        )}
                      </div>
                      {/* Usage bar */}
                      <div className="mt-2 h-1.5 rounded-full bg-muted overflow-hidden">
                        <div
                          className="h-full rounded-full bg-primary transition-all"
                          style={{ width: `${usagePercent}%` }}
                        />
                      </div>
                      {/* Warming progress */}
                      {account.warmingEnabled && account.warmingStartedAt && (
                        <div className="mt-2 space-y-1">
                          <div className="flex justify-between text-[10px] text-muted-foreground">
                            <span>养号进度</span>
                            <span>
                              第{Math.max(0, Math.round((Date.now() - new Date(account.warmingStartedAt).getTime()) / 86400000))}天
                              / {account.warmingDays ?? 30}天
                            </span>
                          </div>
                          <div className="h-1 rounded-full bg-orange-100 dark:bg-orange-950 overflow-hidden">
                            <div
                              className="h-full rounded-full bg-orange-400 transition-all"
                              style={{
                                width: `${Math.min(100, Math.round(
                                  (Math.max(0, (Date.now() - new Date(account.warmingStartedAt).getTime()) / 86400000) /
                                    (account.warmingDays ?? 30)) * 100
                                ))}%`,
                              }}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col gap-1 shrink-0">
                      <Button
                        size="icon-sm"
                        variant="ghost"
                        onClick={() => handleToggleConnect(account._id, account.status)}
                        title={account.status === "connected" ? "断开" : "连接"}
                      >
                        {account.status === "connected" ? (
                          <WifiOff className="size-4" />
                        ) : (
                          <Wifi className="size-4" />
                        )}
                      </Button>
                      <Button
                        size="icon-sm"
                        variant="ghost"
                        onClick={() => setWarmingAccount(account)}
                        title="养号设置"
                        className={account.warmingEnabled ? "text-orange-400" : "text-muted-foreground"}
                      >
                        {account.warmingEnabled ? (
                          <Flame className="size-4" />
                        ) : (
                          <Settings2 className="size-4" />
                        )}
                      </Button>
                      <Button
                        size="icon-sm"
                        variant="ghost"
                        className="text-muted-foreground hover:text-destructive"
                        onClick={() => handleDelete(account._id)}
                        title="删除"
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Warming settings sheet */}
      <WarmingSettingsSheet
        account={warmingAccount}
        open={warmingAccount !== null}
        onClose={() => setWarmingAccount(null)}
      />
    </div>
  );
}
