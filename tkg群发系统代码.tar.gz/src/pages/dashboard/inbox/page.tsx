import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import { formatDistanceToNow } from "date-fns";
import { zhCN } from "date-fns/locale";
import {
  MessageSquare,
  Search,
  Send,
  CheckCheck,
  Clock,
  CheckCircle2,
  Inbox,
  RefreshCw,
  MoreHorizontal,
  Phone,
  User,
  Sparkles,
} from "lucide-react";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription, EmptyContent } from "@/components/ui/empty.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import { cn } from "@/lib/utils.ts";

type StatusFilter = "all" | "open" | "resolved" | "pending";
type ConvStatus = "open" | "resolved" | "pending";

const STATUS_TABS: { id: StatusFilter; label: string }[] = [
  { id: "all", label: "全部" },
  { id: "open", label: "进行中" },
  { id: "pending", label: "待处理" },
  { id: "resolved", label: "已解决" },
];

const STATUS_COLORS: Record<ConvStatus, string> = {
  open: "bg-green-500/15 text-green-600 border-green-300",
  pending: "bg-yellow-500/15 text-yellow-600 border-yellow-300",
  resolved: "bg-muted text-muted-foreground border-border",
};

const STATUS_LABELS: Record<ConvStatus, string> = {
  open: "进行中",
  pending: "待处理",
  resolved: "已解决",
};

export default function InboxPage() {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState<Id<"conversations"> | null>(null);
  const [replyText, setReplyText] = useState("");
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const stats = useQuery(api.inbox.getStats, {});
  const conversations = useQuery(api.inbox.listConversations, {
    status: statusFilter === "all" ? undefined : statusFilter,
    search: search || undefined,
  });
  const selectedConv = useQuery(
    api.inbox.getConversation,
    selectedId ? { conversationId: selectedId } : "skip"
  );
  const messages = useQuery(
    api.inbox.getMessages,
    selectedId ? { conversationId: selectedId } : "skip"
  );

  const sendReply = useMutation(api.inbox.sendReply);
  const markAsRead = useMutation(api.inbox.markAsRead);
  const updateStatus = useMutation(api.inbox.updateStatus);
  const seedDemo = useMutation(api.inbox.seedDemoConversations);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Mark as read when selecting conversation
  useEffect(() => {
    if (selectedId) {
      markAsRead({ conversationId: selectedId }).catch(() => null);
    }
  }, [selectedId, markAsRead]);

  const handleSend = async () => {
    if (!replyText.trim() || !selectedId) return;
    setSending(true);
    try {
      await sendReply({ conversationId: selectedId, content: replyText.trim() });
      setReplyText("");
    } catch (err) {
      if (err instanceof ConvexError) {
        const { message } = err.data as { message: string };
        toast.error(message);
      } else {
        toast.error("发送失败");
      }
    } finally {
      setSending(false);
    }
  };

  const handleStatusChange = async (convId: Id<"conversations">, status: ConvStatus) => {
    try {
      await updateStatus({ conversationId: convId, status });
      toast.success(`已标记为「${STATUS_LABELS[status]}」`);
    } catch {
      toast.error("操作失败");
    }
  };

  const handleSeedDemo = async () => {
    try {
      const result = await seedDemo({});
      if (result.created > 0) {
        toast.success(`已生成 ${result.created} 条演示对话`);
      } else {
        toast.info("演示数据已存在，或暂无联系人");
      }
    } catch {
      toast.error("生成失败");
    }
  };

  const isLoading = conversations === undefined;

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">收件箱</h1>
          <p className="text-muted-foreground text-sm mt-0.5">管理联系人回复与对话</p>
        </div>
        <div className="flex items-center gap-2">
          {/* Stats pills */}
          {stats && (
            <div className="hidden md:flex items-center gap-2">
              {stats.unread > 0 && (
                <Badge className="bg-primary/10 text-primary border-primary/20 gap-1">
                  <span className="size-1.5 rounded-full bg-primary inline-block" />
                  {stats.unread} 未读
                </Badge>
              )}
              <Badge variant="outline" className="gap-1">
                <MessageSquare className="size-3" />
                {stats.open} 进行中
              </Badge>
            </div>
          )}
          <Button variant="ghost" size="sm" onClick={handleSeedDemo} className="gap-2 text-muted-foreground">
            <Sparkles className="size-4" />
            <span className="hidden sm:inline">演示数据</span>
          </Button>
        </div>
      </div>

      {/* Main panel */}
      <div className="flex-1 flex rounded-xl border border-border overflow-hidden min-h-0 bg-card">
        {/* Left: conversation list */}
        <div className={cn(
          "flex flex-col border-r border-border",
          selectedId ? "hidden md:flex w-80 shrink-0" : "flex-1 md:w-80 md:shrink-0 md:flex-none"
        )}>
          {/* Search */}
          <div className="p-3 border-b border-border shrink-0">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                placeholder="搜索联系人或消息..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 h-9 text-sm"
              />
            </div>
          </div>

          {/* Status tabs */}
          <div className="flex px-3 pt-2 pb-0 gap-1 shrink-0 overflow-x-auto">
            {STATUS_TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors",
                  statusFilter === tab.id
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Conversation list */}
          <div className="flex-1 overflow-y-auto py-2">
            {isLoading ? (
              <div className="space-y-1 px-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full rounded-lg" />
                ))}
              </div>
            ) : conversations.length === 0 ? (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon"><Inbox /></EmptyMedia>
                  <EmptyTitle>暂无对话</EmptyTitle>
                  <EmptyDescription>点击「演示数据」生成示例对话</EmptyDescription>
                </EmptyHeader>
                <EmptyContent>
                  <Button size="sm" onClick={handleSeedDemo}>生成演示数据</Button>
                </EmptyContent>
              </Empty>
            ) : (
              conversations.map((conv) => {
                const isSelected = selectedId === conv._id;
                const contact = conv.contact;
                const displayName = contact?.name ?? contact?.phone ?? "未知";
                const initials = displayName[0].toUpperCase();
                const timeAgo = formatDistanceToNow(new Date(conv.lastMessageAt), {
                  addSuffix: true,
                  locale: zhCN,
                });

                return (
                  <button
                    key={conv._id}
                    onClick={() => setSelectedId(conv._id)}
                    className={cn(
                      "w-full flex items-start gap-3 px-3 py-3 mx-1 rounded-lg text-left transition-colors",
                      isSelected
                        ? "bg-primary/10"
                        : "hover:bg-accent"
                    )}
                  >
                    {/* Avatar */}
                    <div className={cn(
                      "size-9 rounded-full flex items-center justify-center text-sm font-bold shrink-0",
                      isSelected ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                    )}>
                      {initials}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-sm font-medium truncate">{displayName}</span>
                        <span className="text-[10px] text-muted-foreground shrink-0">{timeAgo}</span>
                      </div>
                      <p className={cn(
                        "text-xs truncate mt-0.5",
                        conv.unreadCount > 0 ? "font-medium text-foreground" : "text-muted-foreground"
                      )}>
                        {conv.lastMessagePreview}
                      </p>
                      <div className="flex items-center gap-1.5 mt-1">
                        <span className={cn(
                          "text-[10px] px-1.5 py-0.5 rounded border font-medium",
                          STATUS_COLORS[conv.status as ConvStatus]
                        )}>
                          {STATUS_LABELS[conv.status as ConvStatus]}
                        </span>
                        {conv.unreadCount > 0 && (
                          <span className="size-4 rounded-full bg-primary text-primary-foreground text-[9px] font-bold flex items-center justify-center">
                            {conv.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right: chat panel */}
        <div className={cn(
          "flex-1 flex flex-col min-w-0",
          !selectedId && "hidden md:flex"
        )}>
          {!selectedId ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center space-y-3">
                <div className="size-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
                  <MessageSquare className="size-7 text-primary" />
                </div>
                <p className="text-sm text-muted-foreground">选择左侧对话开始查看</p>
              </div>
            </div>
          ) : (
            <>
              {/* Chat header */}
              <div className="flex items-center gap-3 px-4 py-3 border-b border-border shrink-0">
                <button
                  onClick={() => setSelectedId(null)}
                  className="md:hidden text-muted-foreground hover:text-foreground mr-1"
                >
                  ←
                </button>
                {selectedConv ? (
                  <>
                    <div className="size-9 rounded-full bg-primary/20 flex items-center justify-center text-sm font-bold text-primary shrink-0">
                      {(selectedConv.contact?.name ?? selectedConv.contact?.phone ?? "?")[0].toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">
                        {selectedConv.contact?.name ?? selectedConv.contact?.phone ?? "未知"}
                      </p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <Phone className="size-3" />
                        {selectedConv.contact?.phone ?? "-"}
                        {selectedConv.accountName && (
                          <span>· {selectedConv.accountName}</span>
                        )}
                      </p>
                    </div>
                    {/* Status badge + actions */}
                    <div className="flex items-center gap-2">
                      <Badge
                        variant="outline"
                        className={cn(
                          "text-xs hidden sm:inline-flex",
                          STATUS_COLORS[selectedConv.status as ConvStatus]
                        )}
                      >
                        {STATUS_LABELS[selectedConv.status as ConvStatus]}
                      </Badge>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="size-8">
                            <MoreHorizontal className="size-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleStatusChange(selectedConv._id, "open")}>
                            <RefreshCw className="size-4 mr-2" /> 标记为进行中
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleStatusChange(selectedConv._id, "pending")}>
                            <Clock className="size-4 mr-2" /> 标记为待处理
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleStatusChange(selectedConv._id, "resolved")}>
                            <CheckCircle2 className="size-4 mr-2" /> 标记为已解决
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </>
                ) : (
                  <Skeleton className="h-9 flex-1" />
                )}
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {messages === undefined ? (
                  <div className="space-y-3">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <div key={i} className={cn("flex", i % 2 === 0 ? "justify-start" : "justify-end")}>
                        <Skeleton className="h-10 w-48 rounded-2xl" />
                      </div>
                    ))}
                  </div>
                ) : messages.length === 0 ? (
                  <div className="flex-1 flex items-center justify-center h-full">
                    <div className="text-center text-muted-foreground text-sm">
                      <User className="size-8 mx-auto mb-2 opacity-40" />
                      暂无消息记录
                    </div>
                  </div>
                ) : (
                  messages.map((msg) => {
                    const isOutbound = msg.direction === "outbound";
                    const time = new Date(msg.sentAt).toLocaleTimeString("zh-CN", {
                      hour: "2-digit",
                      minute: "2-digit",
                    });
                    return (
                      <div
                        key={msg._id}
                        className={cn("flex gap-2", isOutbound ? "justify-end" : "justify-start")}
                      >
                        <div className={cn(
                          "max-w-[70%] space-y-1",
                          isOutbound ? "items-end" : "items-start",
                          "flex flex-col"
                        )}>
                          <div className={cn(
                            "px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed",
                            isOutbound
                              ? "bg-primary text-primary-foreground rounded-br-sm"
                              : "bg-muted text-foreground rounded-bl-sm"
                          )}>
                            {msg.content}
                          </div>
                          <div className={cn(
                            "flex items-center gap-1 text-[10px] text-muted-foreground px-1",
                            isOutbound ? "flex-row-reverse" : "flex-row"
                          )}>
                            <span>{time}</span>
                            {isOutbound && (
                              <CheckCheck className={cn(
                                "size-3",
                                msg.status === "read" ? "text-blue-500" : "text-muted-foreground"
                              )} />
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Reply input */}
              <div className="px-4 py-3 border-t border-border shrink-0">
                <div className="flex items-end gap-2">
                  <Input
                    placeholder="输入回复内容..."
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSend();
                      }
                    }}
                    className="flex-1 text-sm"
                  />
                  <Button
                    onClick={handleSend}
                    disabled={!replyText.trim() || sending}
                    size="icon"
                    className="shrink-0"
                  >
                    <Send className="size-4" />
                  </Button>
                </div>
                <p className="text-[10px] text-muted-foreground mt-1.5 px-0.5">
                  按 Enter 发送 · Shift+Enter 换行
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
