import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import {
  BarChart3,
  Users,
  Smartphone,
  Megaphone,
  Send,
  CheckCheck,
  Eye,
  MessageSquare,
  TrendingUp,
  XCircle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
} from "@/components/ui/empty.tsx";

const STATUS_LABELS: Record<string, string> = {
  draft: "草稿",
  scheduled: "已安排",
  running: "进行中",
  paused: "已暂停",
  completed: "已完成",
  failed: "失败",
};

const STATUS_COLORS: Record<string, string> = {
  draft: "secondary",
  scheduled: "default",
  running: "default",
  paused: "secondary",
  completed: "default",
  failed: "destructive",
};

const PIE_COLORS = [
  "oklch(0.72 0.19 155)",
  "oklch(0.60 0.15 180)",
  "oklch(0.80 0.15 130)",
  "oklch(0.65 0.12 100)",
  "oklch(0.50 0.10 200)",
  "oklch(0.70 0.18 80)",
  "oklch(0.55 0.14 230)",
  "oklch(0.75 0.16 50)",
];

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  highlight,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  sub?: string;
  highlight?: boolean;
}) {
  return (
    <Card className={highlight ? "border-primary/40 bg-primary/5" : ""}>
      <CardContent className="pt-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-muted-foreground">{label}</p>
            <p className={`text-2xl font-bold mt-1 ${highlight ? "text-primary" : ""}`}>
              {value}
            </p>
            {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
          </div>
          <div
            className={`p-2 rounded-lg ${highlight ? "bg-primary/20" : "bg-muted"}`}
          >
            <Icon className={`h-4 w-4 ${highlight ? "text-primary" : "text-muted-foreground"}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function RateCard({
  label,
  rate,
  icon: Icon,
}: {
  label: string;
  rate: number;
  icon: React.ElementType;
}) {
  const color =
    rate >= 80 ? "text-green-400" : rate >= 50 ? "text-yellow-400" : "text-red-400";
  const bg =
    rate >= 80 ? "bg-green-400/10" : rate >= 50 ? "bg-yellow-400/10" : "bg-red-400/10";

  return (
    <div className={`rounded-xl p-4 ${bg} space-y-2`}>
      <div className="flex items-center gap-2">
        <Icon className={`h-4 w-4 ${color}`} />
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <p className={`text-3xl font-bold ${color}`}>{rate}%</p>
      <div className="w-full bg-muted rounded-full h-1.5">
        <div
          className={`h-1.5 rounded-full transition-all ${
            rate >= 80 ? "bg-green-400" : rate >= 50 ? "bg-yellow-400" : "bg-red-400"
          }`}
          style={{ width: `${rate}%` }}
        />
      </div>
    </div>
  );
}

export default function AnalyticsPage() {
  const data = useQuery(api.analytics.getOverview, {});

  if (data === undefined) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">数据分析</h1>
          <p className="text-sm text-muted-foreground mt-1">营销数据可视化看板</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Skeleton className="h-72 w-full" />
          <Skeleton className="h-72 w-full" />
        </div>
      </div>
    );
  }

  const { summary, statusBreakdown, campaignFunnel, tagDistribution, contactSources, recentCampaigns } =
    data;

  const hasAnyCampaigns = summary.totalCampaigns > 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <BarChart3 className="h-6 w-6 text-primary" />
          数据分析
        </h1>
        <p className="text-sm text-muted-foreground mt-1">营销数据可视化看板</p>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard icon={Megaphone} label="总活动数" value={summary.totalCampaigns} sub={`${summary.activeCampaigns} 个进行中`} />
        <StatCard icon={Users} label="总联系人" value={summary.totalContacts} />
        <StatCard icon={Smartphone} label="账号数" value={summary.totalAccounts} sub={`${summary.connectedAccounts} 已连接`} />
        <StatCard icon={Send} label="总发送量" value={summary.totalSent.toLocaleString()} highlight />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard icon={CheckCheck} label="已送达" value={summary.totalDelivered.toLocaleString()} />
        <StatCard icon={Eye} label="已阅读" value={summary.totalRead.toLocaleString()} />
        <StatCard icon={MessageSquare} label="已回复" value={summary.totalReplied.toLocaleString()} />
        <StatCard icon={XCircle} label="失败" value={summary.totalFailed.toLocaleString()} />
      </div>

      {/* Rate cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <RateCard icon={TrendingUp} label="送达率" rate={summary.deliveryRate} />
        <RateCard icon={Eye} label="阅读率" rate={summary.readRate} />
        <RateCard icon={MessageSquare} label="回复率" rate={summary.replyRate} />
      </div>

      {!hasAnyCampaigns ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <BarChart3 />
            </EmptyMedia>
            <EmptyTitle>暂无活动数据</EmptyTitle>
            <EmptyDescription>创建并运行活动后，这里将显示详细的数据分析图表</EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <>
          {/* Campaign funnel bar chart */}
          {campaignFunnel.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">活动漏斗分析（近期已完成/进行中）</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={campaignFunnel} margin={{ top: 4, right: 8, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.02 155)" />
                    <XAxis
                      dataKey="name"
                      tick={{ fontSize: 11, fill: "oklch(0.65 0.03 155)" }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fontSize: 11, fill: "oklch(0.65 0.03 155)" }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        background: "oklch(0.17 0.015 155)",
                        border: "1px solid oklch(0.28 0.02 155)",
                        borderRadius: "8px",
                        fontSize: "12px",
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: "11px" }} />
                    <Bar dataKey="已发送" fill="oklch(0.50 0.10 200)" radius={[3, 3, 0, 0]} />
                    <Bar dataKey="已送达" fill="oklch(0.60 0.15 180)" radius={[3, 3, 0, 0]} />
                    <Bar dataKey="已阅读" fill="oklch(0.72 0.19 155)" radius={[3, 3, 0, 0]} />
                    <Bar dataKey="已回复" fill="oklch(0.80 0.15 130)" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Campaign status pie */}
            {statusBreakdown.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">活动状态分布</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={220}>
                    <PieChart>
                      <Pie
                        data={statusBreakdown}
                        cx="50%"
                        cy="50%"
                        innerRadius={55}
                        outerRadius={85}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {statusBreakdown.map((entry, index) => (
                          <Cell
                            key={entry.name}
                            fill={PIE_COLORS[index % PIE_COLORS.length]}
                          />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          background: "oklch(0.17 0.015 155)",
                          border: "1px solid oklch(0.28 0.02 155)",
                          borderRadius: "8px",
                          fontSize: "12px",
                        }}
                      />
                      <Legend
                        wrapperStyle={{ fontSize: "11px" }}
                        formatter={(value) => value}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}

            {/* Tag distribution */}
            {tagDistribution.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">联系人标签分布 TOP 8</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart
                      data={tagDistribution}
                      layout="vertical"
                      margin={{ top: 0, right: 16, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        horizontal={false}
                        stroke="oklch(0.28 0.02 155)"
                      />
                      <XAxis
                        type="number"
                        tick={{ fontSize: 10, fill: "oklch(0.65 0.03 155)" }}
                        axisLine={false}
                        tickLine={false}
                      />
                      <YAxis
                        type="category"
                        dataKey="name"
                        width={72}
                        tick={{ fontSize: 10, fill: "oklch(0.65 0.03 155)" }}
                        axisLine={false}
                        tickLine={false}
                      />
                      <Tooltip
                        contentStyle={{
                          background: "oklch(0.17 0.015 155)",
                          border: "1px solid oklch(0.28 0.02 155)",
                          borderRadius: "8px",
                          fontSize: "12px",
                        }}
                      />
                      <Bar dataKey="value" name="人数" fill="oklch(0.72 0.19 155)" radius={[0, 3, 3, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Recent campaigns table */}
          {recentCampaigns.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">最近活动详情</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border/50">
                        <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">活动名称</th>
                        <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">状态</th>
                        <th className="text-right px-4 py-2.5 text-muted-foreground font-medium">目标人数</th>
                        <th className="text-right px-4 py-2.5 text-muted-foreground font-medium">已发送</th>
                        <th className="text-right px-4 py-2.5 text-muted-foreground font-medium">已送达</th>
                        <th className="text-right px-4 py-2.5 text-muted-foreground font-medium">已阅读</th>
                        <th className="text-right px-4 py-2.5 text-muted-foreground font-medium">已回复</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentCampaigns.map((c) => (
                        <tr
                          key={c._id}
                          className="border-b border-border/30 hover:bg-muted/20 transition-colors"
                        >
                          <td className="px-4 py-2.5 font-medium max-w-[160px] truncate">
                            {c.name}
                          </td>
                          <td className="px-4 py-2.5">
                            <Badge
                              variant={
                                (STATUS_COLORS[c.status] as "default" | "secondary" | "destructive") ??
                                "secondary"
                              }
                              className="text-[10px] h-5"
                            >
                              {STATUS_LABELS[c.status] ?? c.status}
                            </Badge>
                          </td>
                          <td className="px-4 py-2.5 text-right text-muted-foreground">
                            {c.totalRecipients}
                          </td>
                          <td className="px-4 py-2.5 text-right">{c.sentCount}</td>
                          <td className="px-4 py-2.5 text-right text-green-400">{c.deliveredCount}</td>
                          <td className="px-4 py-2.5 text-right text-blue-400">{c.readCount}</td>
                          <td className="px-4 py-2.5 text-right text-primary">{c.repliedCount}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
