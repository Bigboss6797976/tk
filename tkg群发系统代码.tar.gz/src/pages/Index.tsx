import HeroSection from "./_components/hero-section.tsx";
import FeaturesSection from "./_components/features-section.tsx";
import FeatureDetailsSection from "./_components/feature-details-section.tsx";
import WorkflowSection from "./_components/workflow-section.tsx";
import EngineSection from "./_components/engine-section.tsx";
import TrustSection from "./_components/trust-section.tsx";
import PricingSection from "./_components/pricing-section.tsx";
import FaqSection from "./_components/faq-section.tsx";
import SummarySection from "./_components/summary-section.tsx";
import FooterSection from "./_components/footer-section.tsx";
import Navbar from "./_components/navbar.tsx";

export default function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      <HeroSection />
      <FeaturesSection />
      <FeatureDetailsSection />
      <WorkflowSection />
      <EngineSection />
      <TrustSection />
      <PricingSection />
      <FaqSection />
      <SummarySection />
      <FooterSection />
    </div>
  );
}
