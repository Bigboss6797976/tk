import { motion } from "motion/react";
import { Globe, Users, MessageSquare, Clock } from "lucide-react";

const STATS = [
  {
    icon: Users,
    value: "50,000+",
    label: "全球活跃用户",
    description: "覆盖 120+ 国家和地区",
  },
  {
    icon: MessageSquare,
    value: "2 亿+",
    label: "消息日发送量",
    description: "日均峰值承载能力",
  },
  {
    icon: Globe,
    value: "99.2%",
    label: "消息送达率",
    description: "行业领先的到达率",
  },
  {
    icon: Clock,
    value: "7x24h",
    label: "AI 客服在线",
    description: "全年无休自动转化",
  },
];

const TRUST_LOGOS = [
  "跨境电商",
  "外贸 B2B",
  "教育培训",
  "金融保险",
  "旅游酒店",
  "电子产品",
];

export default function TrustSection() {
  return (
    <section className="py-20 md:py-28 relative">
      {/* Top divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div className="relative mx-auto max-w-7xl px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase text-primary border border-primary/20 bg-primary/5 mb-6">
            平台实力
          </span>
          <h2 className="text-3xl md:text-5xl font-black tracking-tight">
            数据说话，<span className="text-primary">实力见证</span>
          </h2>
        </motion.div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {STATS.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="rounded-2xl border border-border/60 bg-card/50 p-6 text-center hover:border-primary/40 transition-all duration-300"
            >
              <div className="mx-auto size-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                <stat.icon className="size-6 text-primary" />
              </div>
              <div className="text-3xl md:text-4xl font-black text-primary mb-1">
                {stat.value}
              </div>
              <div className="text-sm font-semibold mb-1">{stat.label}</div>
              <div className="text-xs text-muted-foreground">
                {stat.description}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Industry coverage */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <p className="text-sm text-muted-foreground mb-6 uppercase tracking-wider font-semibold">
            覆盖行业
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            {TRUST_LOGOS.map((industry) => (
              <div
                key={industry}
                className="px-6 py-3 rounded-xl border border-border/60 bg-card/30 text-sm text-muted-foreground font-medium hover:border-primary/30 hover:text-foreground transition-all duration-300"
              >
                {industry}
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
