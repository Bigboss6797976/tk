import { motion } from "motion/react";
import { Button } from "@/components/ui/button.tsx";
import { Play, ArrowRight, Shield, Zap, Bot } from "lucide-react";
import { Link } from "react-router-dom";

const HERO_STATS = [
  { value: "99.2%", label: "送达率" },
  { value: "10x", label: "效率提升" },
  { value: "50K+", label: "全球用户" },
];

const HERO_BADGES = [
  { icon: Shield, text: "防封引擎" },
  { icon: Zap, text: "极速群发" },
  { icon: Bot, text: "AI 驱动" },
];

export default function HeroSection() {
  return (
    <section className="relative pt-28 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[600px] rounded-full bg-primary/8 blur-[120px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full bg-primary/5 blur-[100px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        {/* Badge row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex flex-wrap items-center justify-center gap-3 mb-8"
        >
          {HERO_BADGES.map((badge) => (
            <div
              key={badge.text}
              className="flex items-center gap-2 px-4 py-2 rounded-full border border-primary/20 bg-primary/5 text-sm text-primary"
            >
              <badge.icon className="size-4" />
              {badge.text}
            </div>
          ))}
        </motion.div>

        {/* Main headline */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.7 }}
          className="text-center"
        >
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-black tracking-tight text-balance leading-tight">
            <span className="text-primary">WhatsApp</span> 营销
            <br />
            群发系统
            <span className="inline-block ml-3 px-4 py-1 text-2xl md:text-3xl font-bold rounded-lg bg-primary/15 text-primary align-middle">
              V16.0
            </span>
          </h1>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="mx-auto mt-6 max-w-2xl text-center text-lg md:text-xl text-muted-foreground leading-relaxed"
        >
          2026年最强 WhatsApp 营销全能平台 —— 自用高效 + 白标赚钱，两手抓！
          <br />
          <span className="text-foreground/80 font-medium">
            官方 Cloud API + Baileys 双引擎，群发 / AI 客服 / 养号 / 白标一站搞定
          </span>
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.65, duration: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-10"
        >
          <Button asChild size="lg" className="gap-2 text-base px-8 py-6 font-bold rounded-xl shadow-lg shadow-primary/25">
            <Link to="/dashboard">
              进入系统
              <ArrowRight className="size-5" />
            </Link>
          </Button>
          <Button variant="secondary" size="lg" className="gap-2 text-base px-8 py-6 rounded-xl">
            <Play className="size-5" />
            观看演示视频
          </Button>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="flex items-center justify-center gap-8 md:gap-16 mt-16"
        >
          {HERO_STATS.map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-3xl md:text-4xl font-black text-primary">
                {stat.value}
              </div>
              <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Dashboard preview */}
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ delay: 1, duration: 0.8, ease: "easeOut" }}
          className="mt-16 mx-auto max-w-5xl"
        >
          <div className="relative rounded-2xl border border-border/60 overflow-hidden shadow-2xl shadow-primary/10">
            <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent z-10 pointer-events-none" />
            <img
              src="https://hercules-cdn.com/file_jP95lSA2Yp8QAWMoI2hxesuY"
              alt="TK-G Dashboard Preview"
              className="w-full object-cover"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
