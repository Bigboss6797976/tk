import { MessageSquare } from "lucide-react";

export default function FooterSection() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border/50 py-10">
      <div className="mx-auto max-w-7xl px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div className="size-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <MessageSquare className="size-4 text-primary" />
            </div>
            <span className="text-sm font-bold">
              TK-G <span className="text-primary">V16.0</span>
            </span>
          </div>

          {/* Links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
            <a href="#features" className="hover:text-foreground transition-colors">
              功能介绍
            </a>
            <a href="#engines" className="hover:text-foreground transition-colors">
              双引擎
            </a>
            <a href="#pricing" className="hover:text-foreground transition-colors">
              定价方案
            </a>
            <a href="#faq" className="hover:text-foreground transition-colors">
              常见问题
            </a>
            <a href="#contact" className="hover:text-foreground transition-colors">
              联系我们
            </a>
          </div>

          {/* Copyright */}
          <p className="text-xs text-muted-foreground">
            &copy; {year} TK-G. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
