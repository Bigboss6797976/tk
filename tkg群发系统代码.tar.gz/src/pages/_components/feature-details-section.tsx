import { motion } from "motion/react";
import {
  ShieldCheck,
  Brain,
  FileSpreadsheet,
  BarChart3,
  Package,
  Check,
  ArrowRight,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

type FeatureDetail = {
  id: string;
  icon: LucideIcon;
  tag: string;
  title: string;
  subtitle: string;
  description: string;
  bullets: string[];
  image: string;
};

const FEATURE_DETAILS: FeatureDetail[] = [
  {
    id: "anti-ban",
    icon: ShieldCheck,
    tag: "核心防御",
    title: "全自动养号防封系统",
    subtitle: "模拟真人行为，让你的账号安全持久",
    description:
      "Baileys 引擎内置业界领先的智能养号模块，通过 AI 驱动的行为模拟引擎，自动执行一系列真人操作，从根本上降低非官方账号的封号概率。",
    bullets: [
      "模拟真人聊天节奏 —— 随机延迟、打字速度、已读回执",
      "自动添加老朋友 —— 从通讯录智能匹配并发送问候",
      "群聊互动行为 —— 自动回复、点赞、转发群内消息",
      "随机在线/离线状态 —— 模拟真实使用习惯",
      "多设备指纹轮换 —— 降低单设备风控触发",
      "封号预警机制 —— 检测到风险自动暂停并通知",
    ],
    image: "https://hercules-cdn.com/file_d4IbrLrN1m0pXLgLCOFNai2n",
  },
  {
    id: "ai-powered",
    icon: Brain,
    tag: "AI 引擎",
    title: "Grok AI 智能营销助手",
    subtitle: "从文案生成到客服成交，AI 全程接管",
    description:
      "内置 Grok AI 大语言模型，支持一键生成高转化营销文案，并配备上下文记忆能力的多轮智能客服机器人，7x24 小时不间断自动转化客户。",
    bullets: [
      "AI 智能写文案 —— 输入产品关键词，秒出多套营销话术",
      "上下文记忆对话 —— 多轮交互不丢失客户意图",
      "自动意图识别 —— 判断客户购买意向并推送对应话术",
      "多语言支持 —— 中/英/西/阿等主流语言自动切换",
      "自定义话术模板 —— 结合变量实现个性化回复",
      "人工接管切换 —— 关键时刻无缝转人工客服",
    ],
    image: "https://hercules-cdn.com/file_c7J3WcY2255QdOGDsbut3GRO",
  },
  {
    id: "easy-ops",
    icon: FileSpreadsheet,
    tag: "极简操作",
    title: "Excel 一键导入 · 零门槛上手",
    subtitle: "从导入到发送，3 步搞定大规模群发",
    description:
      "告别繁琐的手动操作。TK-G 支持 Excel/CSV 批量导入联系人，自动去重、标签分组、变量替换，配合多账号并发 Session，让万级群发像发朋友圈一样简单。",
    bullets: [
      "Excel/CSV 一键导入 —— 支持号码、姓名、自定义变量列",
      "智能去重清洗 —— 自动识别并删除重复号码",
      "标签分组管理 —— 按地区 / 行业 / 意向度分类",
      "变量个性化 —— {'{姓名}'} {'{公司}'} 等变量自动替换",
      "多账号独立 Session —— 每个号独立运行互不干扰",
      "定时发送排程 —— 设定时间自动执行发送任务",
    ],
    image: "https://hercules-cdn.com/file_L6qAOmpAl0jHXJyRY7hDKumB",
  },
  {
    id: "analytics",
    icon: BarChart3,
    tag: "数据中枢",
    title: "实时数据可视化看板",
    subtitle: "每一条消息的效果，一目了然",
    description:
      "内置专业级数据分析看板，实时追踪每一次群发任务的打开率、回复率、转化率，以饼图和柱状图直观展示，帮你做出更精准的营销决策。",
    bullets: [
      "实时送达监控 —— 已发送 / 已送达 / 已读 / 已回复全追踪",
      "转化漏斗分析 —— 清晰看到每一步流失点",
      "饼图 + 柱状图 —— 多维度数据可视化展示",
      "任务对比报表 —— A/B 测试不同话术的效果差异",
      "导出 PDF 报告 —— 一键生成专业营销分析报告",
      "异常检测告警 —— 送达率骤降自动预警提醒",
    ],
    image: "https://hercules-cdn.com/file_i4d3Ju3rWwXVk96ORTs1Vguo",
  },
  {
    id: "whitelabel",
    icon: Package,
    tag: "商业变现",
    title: "白标打包 · 打造你的品牌",
    subtitle: "一键换标，把 TK-G 变成你自己的产品卖出去",
    description:
      "TK-G 支持完整白标定制——替换 Logo、修改软件标题、自定义品牌色，一键打包成独立安装程序，让你快速拥有自己的 WhatsApp 营销软件产品线，开启被动收入。",
    bullets: [
      "Logo 替换 —— 上传你的品牌 Logo 即可全局替换",
      "标题自定义 —— 软件名称、关于页面完全可控",
      "品牌色定制 —— 主题色一键切换匹配品牌",
      "独立打包 —— 生成独立 EXE 安装包发给客户",
      "授权管理 —— 按设备/时间/功能灵活授权",
      "定价自由 —— 你定价你销售，差价全归你",
    ],
    image: "https://hercules-cdn.com/file_Uf5UcTCUnyD9sccVb7nFd5tN",
  },
];

export default function FeatureDetailsSection() {
  return (
    <section className="py-20 md:py-28 relative">
      {/* Top divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div className="relative mx-auto max-w-7xl px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase text-primary border border-primary/20 bg-primary/5 mb-6">
            深度解析
          </span>
          <h2 className="text-3xl md:text-5xl font-black tracking-tight">
            每项功能，<span className="text-primary">都是杀手锏</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-xl mx-auto">
            深入了解 TK-G 五大核心模块的强大能力
          </p>
        </motion.div>

        {/* Alternating feature rows */}
        <div className="space-y-28 md:space-y-36">
          {FEATURE_DETAILS.map((feature, i) => {
            const isReversed = i % 2 === 1;

            return (
              <div
                key={feature.id}
                id={`detail-${feature.id}`}
                className={`flex flex-col gap-10 md:gap-16 items-center ${
                  isReversed ? "md:flex-row-reverse" : "md:flex-row"
                }`}
              >
                {/* Text side */}
                <motion.div
                  initial={{ opacity: 0, x: isReversed ? 40 : -40 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-80px" }}
                  transition={{ duration: 0.6 }}
                  className="flex-1 min-w-0"
                >
                  {/* Tag + icon */}
                  <div className="flex items-center gap-3 mb-5">
                    <div className="size-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <feature.icon className="size-5 text-primary" />
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-semibold text-primary border border-primary/20 bg-primary/5">
                      {feature.tag}
                    </span>
                  </div>

                  <h3 className="text-2xl md:text-3xl font-black tracking-tight mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-primary font-medium mb-4">
                    {feature.subtitle}
                  </p>
                  <p className="text-muted-foreground leading-relaxed mb-6">
                    {feature.description}
                  </p>

                  {/* Bullet list */}
                  <ul className="space-y-3">
                    {feature.bullets.map((bullet) => (
                      <li key={bullet} className="flex items-start gap-3">
                        <div className="mt-1 size-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                          <Check className="size-3 text-primary" />
                        </div>
                        <span className="text-sm text-foreground/80 leading-relaxed">
                          {bullet}
                        </span>
                      </li>
                    ))}
                  </ul>

                  {/* Learn more */}
                  <div className="mt-6">
                    <a
                      href="#contact"
                      className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline"
                    >
                      了解更多
                      <ArrowRight className="size-4" />
                    </a>
                  </div>
                </motion.div>

                {/* Image side */}
                <motion.div
                  initial={{ opacity: 0, x: isReversed ? -40 : 40 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-80px" }}
                  transition={{ delay: 0.15, duration: 0.6 }}
                  className="flex-1 min-w-0 w-full"
                >
                  <div className="relative rounded-2xl border border-border/60 overflow-hidden shadow-xl shadow-primary/5 group">
                    {/* Subtle glow on hover */}
                    <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none z-10" />
                    <img
                      src={feature.image}
                      alt={feature.title}
                      className="w-full object-cover aspect-[3/2]"
                    />
                  </div>
                </motion.div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
