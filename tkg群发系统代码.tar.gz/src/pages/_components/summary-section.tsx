import { motion } from "motion/react";
import { Button } from "@/components/ui/button.tsx";
import { ArrowRight, MessageSquare, Mail, Phone } from "lucide-react";

export default function SummarySection() {
  return (
    <section id="contact" className="py-24 md:py-32 relative">
      {/* Divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div className="relative mx-auto max-w-7xl px-6">
        {/* Summary block */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto text-center"
        >
          <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full border border-primary/30 bg-primary/5 text-primary text-sm font-semibold mb-8">
            <MessageSquare className="size-4" />
            一句话总结
          </div>

          <h2 className="text-3xl md:text-5xl lg:text-6xl font-black tracking-tight leading-tight">
            TK-G 不只是群发工具
            <br />
            <span className="text-primary">
              而是你的 WhatsApp 私人营销军团
            </span>
            <br />
            + 持续赚钱机器！
          </h2>
        </motion.div>

        {/* CTA card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ delay: 0.2, duration: 0.7 }}
          className="mt-16 mx-auto max-w-3xl rounded-3xl border border-primary/20 bg-gradient-to-br from-primary/10 via-card to-card p-10 md:p-14 text-center"
        >
          <h3 className="text-2xl md:text-3xl font-bold mb-4">
            立即开始你的 WhatsApp 营销之旅
          </h3>
          <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
            加入全球 50,000+ 用户，体验 2026 年最强 WhatsApp 营销平台
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
            <Button
              size="lg"
              className="gap-2 text-base px-8 py-6 font-bold rounded-xl shadow-lg shadow-primary/25"
            >
              免费试用
              <ArrowRight className="size-5" />
            </Button>
            <Button
              variant="secondary"
              size="lg"
              className="gap-2 text-base px-8 py-6 rounded-xl"
            >
              联系我们
            </Button>
          </div>

          {/* Contact info */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-sm text-muted-foreground">
            <a href="#" className="flex items-center gap-2 hover:text-primary transition-colors">
              <Mail className="size-4" />
              support@tk-g.com
            </a>
            <a href="#" className="flex items-center gap-2 hover:text-primary transition-colors">
              <Phone className="size-4" />
              +86 400-XXX-XXXX
            </a>
            <a href="#" className="flex items-center gap-2 hover:text-primary transition-colors">
              <MessageSquare className="size-4" />
              WhatsApp 咨询
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
