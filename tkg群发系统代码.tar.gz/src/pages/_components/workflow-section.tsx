import { motion } from "motion/react";
import {
  Upload,
  Settings2,
  Send,
  TrendingUp,
  ArrowDown,
} from "lucide-react";

const STEPS = [
  {
    step: "01",
    icon: Upload,
    title: "导入联系人",
    description: "Excel/CSV 一键导入，自动去重、分组、标签管理",
  },
  {
    step: "02",
    icon: Settings2,
    title: "配置任务",
    description: "选择引擎、编辑话术、设置变量、定时排程",
  },
  {
    step: "03",
    icon: Send,
    title: "智能群发",
    description: "多账号并发执行，AI 智能调控发送节奏防封",
  },
  {
    step: "04",
    icon: TrendingUp,
    title: "数据追踪",
    description: "实时看板监控效果，AI 客服自动跟进转化",
  },
];

export default function WorkflowSection() {
  return (
    <section className="py-20 md:py-28 relative">
      {/* Top divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      {/* Glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] rounded-full bg-primary/5 blur-[120px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase text-primary border border-primary/20 bg-primary/5 mb-6">
            使用流程
          </span>
          <h2 className="text-3xl md:text-5xl font-black tracking-tight">
            <span className="text-primary">4 步</span>开启高效营销
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-lg mx-auto">
            从导入到转化，整个流程不到 10 分钟
          </p>
        </motion.div>

        {/* Steps - vertical on mobile, horizontal on desktop */}
        <div className="grid md:grid-cols-4 gap-6 md:gap-4">
          {STEPS.map((step, i) => (
            <motion.div
              key={step.step}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ delay: i * 0.12, duration: 0.5 }}
              className="relative"
            >
              {/* Connector arrow (hidden on last item) */}
              {i < STEPS.length - 1 && (
                <>
                  {/* Desktop horizontal arrow */}
                  <div className="hidden md:block absolute top-12 -right-3 z-10">
                    <ArrowDown className="size-5 text-primary/40 -rotate-90" />
                  </div>
                  {/* Mobile vertical arrow */}
                  <div className="md:hidden absolute -bottom-4 left-1/2 -translate-x-1/2 z-10">
                    <ArrowDown className="size-5 text-primary/40" />
                  </div>
                </>
              )}

              <div className="rounded-2xl border border-border/60 bg-card/50 p-6 text-center hover:border-primary/40 hover:bg-card transition-all duration-300 h-full">
                {/* Step number */}
                <div className="text-xs font-mono font-bold text-primary/50 mb-3">
                  STEP {step.step}
                </div>

                {/* Icon */}
                <div className="mx-auto size-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                  <step.icon className="size-7 text-primary" />
                </div>

                <h3 className="text-lg font-bold mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
