import { motion } from "motion/react";
import {
  ShieldCheck,
  Brain,
  FileSpreadsheet,
  BarChart3,
  Package,
} from "lucide-react";

const FEATURES = [
  {
    icon: ShieldCheck,
    title: "防封能力领先",
    description:
      "Baileys 引擎全新自动养号模式 —— 模拟真人聊天、添加老朋友、群聊互动、随机行为，大幅降低非官方账号封号风险。",
    highlight: "养号防封",
  },
  {
    icon: Brain,
    title: "AI 智能驱动",
    description:
      "内置 Grok AI 智能写文案 + 上下文记忆多轮客服机器人，实现真正自动化成交，7x24 小时不间断转化。",
    highlight: "Grok AI",
  },
  {
    icon: FileSpreadsheet,
    title: "操作极简",
    description:
      "Excel 一键导入联系人（自动去重 + 标签 + 变量），多账号独立 Session 并发管理，零门槛上手。",
    highlight: "一键导入",
  },
  {
    icon: BarChart3,
    title: "数据可视化",
    description:
      "实时监控打开率、回复率、转化率（饼图 / 柱状图），一切尽在掌握，数据驱动决策更精准。",
    highlight: "实时监控",
  },
  {
    icon: Package,
    title: "商业变现",
    description:
      "支持白标换 Logo + 自定义标题，一键打包售卖，快速打造属于你自己的 WhatsApp 营销软件品牌。",
    highlight: "白标赚钱",
  },
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-24 md:py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase text-primary border border-primary/20 bg-primary/5 mb-6">
            核心功能
          </span>
          <h2 className="text-3xl md:text-5xl font-black tracking-tight">
            为什么选择 <span className="text-primary">TK-G</span>？
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-xl mx-auto">
            一套系统搞定群发、客服、养号、白标，全方位覆盖你的营销需求
          </p>
        </motion.div>

        {/* Feature grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURES.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className={`group relative rounded-2xl border border-border/60 bg-card/50 p-8 hover:border-primary/40 hover:bg-card transition-all duration-300 ${
                i === 4 ? "md:col-span-2 lg:col-span-1" : ""
              }`}
            >
              {/* Hover glow */}
              <div className="absolute inset-0 rounded-2xl bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

              <div className="relative">
                <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="size-6 text-primary" />
                </div>

                <div className="inline-block px-2.5 py-0.5 rounded-md text-xs font-semibold text-primary bg-primary/10 mb-3">
                  {feature.highlight}
                </div>

                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed text-sm">
                  {feature.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
