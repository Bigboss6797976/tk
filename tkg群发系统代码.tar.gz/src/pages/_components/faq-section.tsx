import { motion } from "motion/react";
import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils.ts";

type FaqItem = {
  question: string;
  answer: string;
};

const FAQ_ITEMS: FaqItem[] = [
  {
    question: "TK-G 需要安装吗？支持什么系统？",
    answer:
      "TK-G 目前提供 Windows 桌面端软件，下载安装即可使用。同时也支持通过浏览器远程访问控制面板，方便随时随地管理任务。Mac 版本正在开发中。",
  },
  {
    question: "使用非官方 Baileys 引擎会被封号吗？",
    answer:
      "任何非官方渠道都存在一定风险，但 TK-G 的自动养号防封系统通过模拟真人行为（聊天、加好友、群互动、随机延迟等）大幅降低封号概率。我们的用户实测封号率低于 3%，远低于行业平均水平。",
  },
  {
    question: "官方 Cloud API 和 Baileys 引擎有什么区别？",
    answer:
      "官方 Cloud API 由 Meta 提供，稳定性最高、零封号风险，但需要申请商业号并通过模板审核。Baileys 引擎无需审核，支持更灵活的个性化群发，但需配合养号模块使用。专业版同时支持双引擎，可根据场景灵活切换。",
  },
  {
    question: "白标版可以完全自定义品牌吗？",
    answer:
      "是的。企业版支持完整白标定制——替换 Logo、修改软件名称和关于页面、自定义主题色，并打包成独立 EXE 安装程序。你的客户完全看不到 TK-G 的品牌痕迹。同时提供授权管理系统，按设备/时间/功能灵活控制。",
  },
  {
    question: "免费试用包含哪些功能？",
    answer:
      "所有方案均提供 7 天免费试用，试用期间可体验所选方案的全部功能，不限制使用。试用到期后可选择续费，也可随时取消，不会收取任何费用。",
  },
  {
    question: "如何保障数据安全？",
    answer:
      "TK-G 采用端到端加密存储，所有联系人数据和聊天记录仅保存在你的本地设备上，不会上传到云端。多账号 Session 独立隔离，确保账号间数据不交叉。我们承诺不收集、不存储、不转售任何用户数据。",
  },
];

export default function FaqSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleItem = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 md:py-28 relative">
      {/* Top divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div className="relative mx-auto max-w-4xl px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase text-primary border border-primary/20 bg-primary/5 mb-6">
            常见问题
          </span>
          <h2 className="text-3xl md:text-5xl font-black tracking-tight">
            你可能想问的<span className="text-primary">问题</span>
          </h2>
        </motion.div>

        {/* FAQ accordion */}
        <div className="space-y-3">
          {FAQ_ITEMS.map((item, i) => {
            const isOpen = openIndex === i;

            return (
              <motion.div
                key={item.question}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ delay: i * 0.06, duration: 0.4 }}
              >
                <button
                  onClick={() => toggleItem(i)}
                  className={cn(
                    "w-full text-left rounded-xl border px-6 py-5 transition-all duration-300",
                    isOpen
                      ? "border-primary/40 bg-card"
                      : "border-border/60 bg-card/50 hover:border-primary/20"
                  )}
                >
                  <div className="flex items-center justify-between gap-4">
                    <span className="font-semibold text-sm md:text-base">
                      {item.question}
                    </span>
                    <ChevronDown
                      className={cn(
                        "size-5 text-muted-foreground shrink-0 transition-transform duration-300",
                        isOpen && "rotate-180 text-primary"
                      )}
                    />
                  </div>

                  {isOpen && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      transition={{ duration: 0.3 }}
                      className="mt-4 text-sm text-muted-foreground leading-relaxed border-t border-border/40 pt-4"
                    >
                      {item.answer}
                    </motion.div>
                  )}
                </button>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
