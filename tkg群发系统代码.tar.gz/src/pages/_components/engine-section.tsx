import { motion } from "motion/react";
import { Cloud, Code2, Check } from "lucide-react";

const ENGINES = [
  {
    icon: Cloud,
    name: "官方 Cloud API",
    tag: "Official",
    tagColor: "bg-blue-500/10 text-blue-400 border-blue-500/20",
    benefits: [
      "Meta 官方认证，稳定可靠",
      "企业级大规模推送",
      "官方绿标认证号支持",
      "自动回复 + Webhook 集成",
      "模板消息审核通过即发",
    ],
  },
  {
    icon: Code2,
    name: "Baileys 增强引擎",
    tag: "Enhanced",
    tagColor: "bg-primary/10 text-primary border-primary/20",
    benefits: [
      "无需 Meta 审核，即装即用",
      "全自动养号防封系统",
      "个性化变量群发（无模板限制）",
      "模拟真人行为：聊天 / 加好友 / 群互动",
      "多账号独立 Session 并发",
    ],
  },
];

export default function EngineSection() {
  return (
    <section id="engines" className="py-24 md:py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-primary/5 blur-[150px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase text-primary border border-primary/20 bg-primary/5 mb-6">
            双引擎架构
          </span>
          <h2 className="text-3xl md:text-5xl font-black tracking-tight">
            一套系统，<span className="text-primary">双引擎</span>并行
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-xl mx-auto">
            同时拥有官方 WhatsApp Business Cloud API + 增强版 Baileys 非官方引擎
          </p>
        </motion.div>

        {/* Engine cards */}
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {ENGINES.map((engine, i) => (
            <motion.div
              key={engine.name}
              initial={{ opacity: 0, x: i === 0 ? -30 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ delay: i * 0.15, duration: 0.6 }}
              className="relative rounded-2xl border border-border/60 bg-card/50 p-8 hover:border-primary/40 transition-all duration-300"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="size-14 rounded-xl bg-primary/10 flex items-center justify-center">
                  <engine.icon className="size-7 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">{engine.name}</h3>
                  <span
                    className={`inline-block mt-1 px-2.5 py-0.5 rounded-md text-xs font-semibold border ${engine.tagColor}`}
                  >
                    {engine.tag}
                  </span>
                </div>
              </div>

              <ul className="space-y-3">
                {engine.benefits.map((benefit) => (
                  <li key={benefit} className="flex items-start gap-3">
                    <div className="mt-0.5 size-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <Check className="size-3 text-primary" />
                    </div>
                    <span className="text-sm text-muted-foreground leading-relaxed">
                      {benefit}
                    </span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
