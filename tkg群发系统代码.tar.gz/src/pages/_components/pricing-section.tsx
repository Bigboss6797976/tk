import { motion } from "motion/react";
import { Check, X, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { cn } from "@/lib/utils.ts";

type PlanFeature = {
  text: string;
  included: boolean;
};

type Plan = {
  name: string;
  tag?: string;
  price: string;
  period: string;
  description: string;
  features: PlanFeature[];
  cta: string;
  popular?: boolean;
};

const PLANS: Plan[] = [
  {
    name: "基础版",
    price: "$299",
    period: "/月",
    description: "适合个人卖家和小型团队入门使用",
    features: [
      { text: "Baileys 引擎（1 个账号）", included: true },
      { text: "每日群发上限 5,000 条", included: true },
      { text: "Excel 联系人导入", included: true },
      { text: "基础数据报表", included: true },
      { text: "AI 文案生成（50次/天）", included: true },
      { text: "官方 Cloud API 引擎", included: false },
      { text: "AI 多轮客服机器人", included: false },
      { text: "自动养号防封模块", included: false },
      { text: "白标定制打包", included: false },
      { text: "专属客户经理", included: false },
    ],
    cta: "开始试用",
  },
  {
    name: "专业版",
    tag: "最受欢迎",
    price: "$799",
    period: "/月",
    description: "适合中型团队和专业营销人员",
    popular: true,
    features: [
      { text: "双引擎（Cloud API + Baileys）", included: true },
      { text: "每日群发上限 50,000 条", included: true },
      { text: "Excel 联系人导入 + 智能去重", included: true },
      { text: "高级可视化数据看板", included: true },
      { text: "AI 文案生成（无限次）", included: true },
      { text: "AI 多轮客服机器人", included: true },
      { text: "自动养号防封模块", included: true },
      { text: "多账号并发（最多 10 个）", included: true },
      { text: "白标定制打包", included: false },
      { text: "专属客户经理", included: false },
    ],
    cta: "立即购买",
  },
  {
    name: "企业版",
    price: "$1,999",
    period: "/月",
    description: "适合大型企业和白标代理商",
    features: [
      { text: "双引擎（Cloud API + Baileys）", included: true },
      { text: "每日群发无上限", included: true },
      { text: "全功能联系人管理系统", included: true },
      { text: "高级看板 + PDF 报告导出", included: true },
      { text: "AI 文案 + 客服（全功能）", included: true },
      { text: "全自动养号防封系统", included: true },
      { text: "多账号并发（无限制）", included: true },
      { text: "白标定制 + 独立打包", included: true },
      { text: "授权管理系统", included: true },
      { text: "专属客户经理 + 优先支持", included: true },
    ],
    cta: "联系销售",
  },
];

export default function PricingSection() {
  return (
    <section id="pricing" className="py-20 md:py-28 relative">
      {/* Top divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      {/* Background glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[800px] h-[500px] rounded-full bg-primary/5 blur-[140px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase text-primary border border-primary/20 bg-primary/5 mb-6">
            定价方案
          </span>
          <h2 className="text-3xl md:text-5xl font-black tracking-tight">
            选择适合你的<span className="text-primary">方案</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-xl mx-auto">
            所有方案均支持 7 天免费试用，不满意随时取消
          </p>
        </motion.div>

        {/* Pricing cards */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 max-w-6xl mx-auto">
          {PLANS.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ delay: i * 0.12, duration: 0.5 }}
              className={cn(
                "relative rounded-2xl border p-8 flex flex-col transition-all duration-300",
                plan.popular
                  ? "border-primary/50 bg-gradient-to-b from-primary/10 via-card to-card shadow-xl shadow-primary/10 scale-[1.02] md:scale-105"
                  : "border-border/60 bg-card/50 hover:border-primary/30"
              )}
            >
              {/* Popular badge */}
              {plan.tag && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                  <div className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-primary text-primary-foreground text-xs font-bold shadow-lg shadow-primary/30">
                    <Sparkles className="size-3.5" />
                    {plan.tag}
                  </div>
                </div>
              )}

              {/* Plan name */}
              <h3 className="text-xl font-bold mb-1">{plan.name}</h3>
              <p className="text-sm text-muted-foreground mb-5">
                {plan.description}
              </p>

              {/* Price */}
              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-4xl md:text-5xl font-black text-primary">
                  {plan.price}
                </span>
                <span className="text-muted-foreground text-sm">
                  {plan.period}
                </span>
              </div>

              {/* CTA button */}
              <Button
                size="lg"
                className={cn(
                  "w-full rounded-xl font-bold mb-8",
                  plan.popular
                    ? "shadow-lg shadow-primary/25"
                    : ""
                )}
                variant={plan.popular ? "default" : "secondary"}
              >
                {plan.cta}
              </Button>

              {/* Features list */}
              <ul className="space-y-3 flex-1">
                {plan.features.map((feature) => (
                  <li key={feature.text} className="flex items-start gap-3">
                    {feature.included ? (
                      <div className="mt-0.5 size-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <Check className="size-3 text-primary" />
                      </div>
                    ) : (
                      <div className="mt-0.5 size-5 rounded-full bg-muted flex items-center justify-center shrink-0">
                        <X className="size-3 text-muted-foreground/50" />
                      </div>
                    )}
                    <span
                      className={cn(
                        "text-sm leading-relaxed",
                        feature.included
                          ? "text-foreground/80"
                          : "text-muted-foreground/50"
                      )}
                    >
                      {feature.text}
                    </span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Bottom note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="text-center text-sm text-muted-foreground mt-10"
        >
          需要定制方案？
          <a href="#contact" className="text-primary font-semibold hover:underline ml-1">
            联系我们的销售团队
          </a>
          ，获取专属报价。
        </motion.p>
      </div>
    </section>
  );
}
