import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { ConvexError } from "convex/values";

export const listHistory = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "请先登录",
        code: "UNAUTHENTICATED",
      });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({ message: "用户不存在", code: "NOT_FOUND" });
    }

    return await ctx.db
      .query("aiCopyHistory")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .take(50);
  },
});

export const saveToHistory = mutation({
  args: {
    prompt: v.string(),
    result: v.string(),
    category: v.union(
      v.literal("marketing"),
      v.literal("followup"),
      v.literal("greeting"),
      v.literal("promotion"),
      v.literal("custom")
    ),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "请先登录",
        code: "UNAUTHENTICATED",
      });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({ message: "用户不存在", code: "NOT_FOUND" });
    }

    await ctx.db.insert("aiCopyHistory", {
      userId: user._id,
      prompt: args.prompt,
      result: args.result,
      category: args.category,
      createdAt: new Date().toISOString(),
    });
  },
});

export const deleteHistory = mutation({
  args: { id: v.id("aiCopyHistory") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "请先登录",
        code: "UNAUTHENTICATED",
      });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();
    if (!user) {
      throw new ConvexError({ message: "用户不存在", code: "NOT_FOUND" });
    }

    const record = await ctx.db.get(args.id);
    if (!record) {
      throw new ConvexError({ message: "记录不存在", code: "NOT_FOUND" });
    }
    if (record.userId !== user._id) {
      throw new ConvexError({ message: "无权删除此记录", code: "FORBIDDEN" });
    }
    await ctx.db.delete(args.id);
  },
});
