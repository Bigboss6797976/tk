import { ConvexError } from "convex/values";
import { query } from "./_generated/server";

export const getOverview = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const campaigns = await ctx.db
      .query("campaigns")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .collect();

    const contacts = await ctx.db
      .query("contacts")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();

    const accounts = await ctx.db
      .query("accounts")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();

    // Aggregate totals
    const totalSent = campaigns.reduce((acc, c) => acc + c.sentCount, 0);
    const totalDelivered = campaigns.reduce((acc, c) => acc + c.deliveredCount, 0);
    const totalRead = campaigns.reduce((acc, c) => acc + c.readCount, 0);
    const totalReplied = campaigns.reduce((acc, c) => acc + c.repliedCount, 0);
    const totalFailed = campaigns.reduce((acc, c) => acc + c.failedCount, 0);

    // Campaign status breakdown
    const statusBreakdown = [
      { name: "草稿", value: campaigns.filter((c) => c.status === "draft").length, color: "#6b7280" },
      { name: "已安排", value: campaigns.filter((c) => c.status === "scheduled").length, color: "#3b82f6" },
      { name: "进行中", value: campaigns.filter((c) => c.status === "running").length, color: "#f59e0b" },
      { name: "已完成", value: campaigns.filter((c) => c.status === "completed").length, color: "#10b981" },
      { name: "已暂停", value: campaigns.filter((c) => c.status === "paused").length, color: "#8b5cf6" },
      { name: "失败", value: campaigns.filter((c) => c.status === "failed").length, color: "#ef4444" },
    ].filter((s) => s.value > 0);

    // Per-campaign funnel (top 8 most recent completed/running)
    const campaignFunnel = campaigns
      .filter((c) => c.status === "completed" || c.status === "running")
      .slice(0, 8)
      .map((c) => ({
        name: c.name.length > 10 ? c.name.slice(0, 10) + "…" : c.name,
        已发送: c.sentCount,
        已送达: c.deliveredCount,
        已阅读: c.readCount,
        已回复: c.repliedCount,
      }))
      .reverse();

    // Contact tag distribution (top 8 tags)
    const tagCounts: Record<string, number> = {};
    for (const contact of contacts) {
      for (const tag of contact.tags) {
        tagCounts[tag] = (tagCounts[tag] ?? 0) + 1;
      }
    }
    const tagDistribution = Object.entries(tagCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([name, value]) => ({ name, value }));

    // Contact source breakdown
    const contactSources = [
      { name: "手动添加", value: contacts.filter((c) => c.source === "manual").length },
      { name: "导入", value: contacts.filter((c) => c.source === "import").length },
    ].filter((s) => s.value > 0);

    // Account engine breakdown
    const engineBreakdown = [
      { name: "Cloud API", value: accounts.filter((a) => a.engine === "cloud_api").length },
      { name: "Baileys", value: accounts.filter((a) => a.engine === "baileys").length },
    ].filter((s) => s.value > 0);

    return {
      summary: {
        totalCampaigns: campaigns.length,
        activeCampaigns: campaigns.filter(
          (c) => c.status === "running" || c.status === "scheduled"
        ).length,
        totalContacts: contacts.length,
        totalAccounts: accounts.length,
        connectedAccounts: accounts.filter((a) => a.status === "connected").length,
        totalSent,
        totalDelivered,
        totalRead,
        totalReplied,
        totalFailed,
        deliveryRate: totalSent > 0 ? Math.round((totalDelivered / totalSent) * 100) : 0,
        readRate: totalDelivered > 0 ? Math.round((totalRead / totalDelivered) * 100) : 0,
        replyRate: totalRead > 0 ? Math.round((totalReplied / totalRead) * 100) : 0,
      },
      statusBreakdown,
      campaignFunnel,
      tagDistribution,
      contactSources,
      engineBreakdown,
      recentCampaigns: campaigns.slice(0, 6).map((c) => ({
        _id: c._id,
        name: c.name,
        status: c.status,
        sentCount: c.sentCount,
        deliveredCount: c.deliveredCount,
        readCount: c.readCount,
        repliedCount: c.repliedCount,
        totalRecipients: c.totalRecipients,
        createdAt: c.createdAt,
      })),
    };
  },
});
