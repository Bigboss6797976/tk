import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  users: defineTable({
    tokenIdentifier: v.string(),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    // Profile fields
    avatar: v.optional(v.string()),
    company: v.optional(v.string()),
    phone: v.optional(v.string()),
    bio: v.optional(v.string()),
    timezone: v.optional(v.string()),
    language: v.optional(v.string()),
    // Notification preferences
    notifyOnReply: v.optional(v.boolean()),
    notifyOnDelivery: v.optional(v.boolean()),
    notifyOnFailure: v.optional(v.boolean()),
    updatedAt: v.optional(v.string()),
  }).index("by_token", ["tokenIdentifier"]),

  // WhatsApp accounts (official Cloud API or Baileys)
  accounts: defineTable({
    userId: v.id("users"),
    name: v.string(),
    phone: v.string(),
    engine: v.union(v.literal("cloud_api"), v.literal("baileys")),
    status: v.union(
      v.literal("connected"),
      v.literal("disconnected"),
      v.literal("warming")
    ),
    dailySendLimit: v.number(),
    sentToday: v.number(),
    lastActiveAt: v.optional(v.string()),
    // 养号 / 限速设置
    warmingEnabled: v.optional(v.boolean()),
    warmingDays: v.optional(v.number()),        // 养号周期（天）
    warmingStartCount: v.optional(v.number()),  // 起始每日发送量
    warmingIncrement: v.optional(v.number()),   // 每日递增量
    warmingStartedAt: v.optional(v.string()),   // 养号开始时间
    sendIntervalMin: v.optional(v.number()),    // 发送最小间隔（秒）
    sendIntervalMax: v.optional(v.number()),    // 发送最大间隔（秒）
    sessionBreakMin: v.optional(v.number()),    // 批次间休息最小（分钟）
    sessionBreakMax: v.optional(v.number()),    // 批次间休息最大（分钟）
    batchSize: v.optional(v.number()),          // 每批发送数量
  }).index("by_user", ["userId"]),

  // Contacts
  contacts: defineTable({
    userId: v.id("users"),
    phone: v.string(),
    name: v.optional(v.string()),
    tags: v.array(v.string()),
    variables: v.optional(
      v.record(v.string(), v.string())
    ),
    source: v.union(v.literal("import"), v.literal("manual")),
    createdAt: v.string(),
  })
    .index("by_user", ["userId"])
    .index("by_user_phone", ["userId", "phone"]),

  // Campaigns (bulk send tasks)
  campaigns: defineTable({
    userId: v.id("users"),
    name: v.string(),
    accountId: v.optional(v.id("accounts")),
    content: v.string(),
    mediaUrl: v.optional(v.string()),
    status: v.union(
      v.literal("draft"),
      v.literal("scheduled"),
      v.literal("running"),
      v.literal("paused"),
      v.literal("completed"),
      v.literal("failed")
    ),
    scheduledAt: v.optional(v.string()),
    targetTags: v.array(v.string()),
    totalRecipients: v.number(),
    sentCount: v.number(),
    deliveredCount: v.number(),
    readCount: v.number(),
    repliedCount: v.number(),
    failedCount: v.number(),
    createdAt: v.string(),
    completedAt: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_user_status", ["userId", "status"]),

  // Individual messages within a campaign
  campaignMessages: defineTable({
    campaignId: v.id("campaigns"),
    contactId: v.id("contacts"),
    accountId: v.optional(v.id("accounts")),
    status: v.union(
      v.literal("pending"),
      v.literal("sent"),
      v.literal("delivered"),
      v.literal("read"),
      v.literal("replied"),
      v.literal("failed")
    ),
    sentAt: v.optional(v.string()),
    error: v.optional(v.string()),
  })
    .index("by_campaign", ["campaignId"])
    .index("by_campaign_status", ["campaignId", "status"]),

  // Message templates
  messageTemplates: defineTable({
    userId: v.id("users"),
    name: v.string(),
    content: v.string(),
    category: v.union(
      v.literal("marketing"),
      v.literal("followup"),
      v.literal("greeting"),
      v.literal("promotion"),
      v.literal("custom")
    ),
    tags: v.array(v.string()),
    usageCount: v.number(),
    createdAt: v.string(),
    updatedAt: v.string(),
  })
    .index("by_user", ["userId"])
    .index("by_user_category", ["userId", "category"]),

  // Conversations (one per contact per account)
  conversations: defineTable({
    userId: v.id("users"),
    contactId: v.id("contacts"),
    accountId: v.optional(v.id("accounts")),
    lastMessageAt: v.string(),
    lastMessagePreview: v.string(),
    unreadCount: v.number(),
    status: v.union(
      v.literal("open"),
      v.literal("resolved"),
      v.literal("pending")
    ),
    assignedTo: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_user_status", ["userId", "status"])
    .index("by_user_lastMessage", ["userId", "lastMessageAt"])
    .index("by_contact", ["contactId"]),

  // Individual inbox messages (inbound + outbound replies)
  inboxMessages: defineTable({
    conversationId: v.id("conversations"),
    userId: v.id("users"),
    direction: v.union(v.literal("inbound"), v.literal("outbound")),
    content: v.string(),
    mediaUrl: v.optional(v.string()),
    mediaType: v.optional(v.union(v.literal("image"), v.literal("audio"), v.literal("document"))),
    status: v.union(
      v.literal("sent"),
      v.literal("delivered"),
      v.literal("read"),
      v.literal("failed")
    ),
    sentAt: v.string(),
  })
    .index("by_conversation", ["conversationId"])
    .index("by_conversation_sent", ["conversationId", "sentAt"]),

  // AI copy generation history
  aiCopyHistory: defineTable({
    userId: v.id("users"),
    prompt: v.string(),
    result: v.string(),
    category: v.union(
      v.literal("marketing"),
      v.literal("followup"),
      v.literal("greeting"),
      v.literal("promotion"),
      v.literal("custom")
    ),
    createdAt: v.string(),
  }).index("by_user", ["userId"]),
});
