/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as accounts from "../accounts.js";
import type * as aiCopy from "../aiCopy.js";
import type * as aiCopyActions from "../aiCopyActions.js";
import type * as analytics from "../analytics.js";
import type * as campaigns from "../campaigns.js";
import type * as contacts from "../contacts.js";
import type * as inbox from "../inbox.js";
import type * as messageTemplates from "../messageTemplates.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  accounts: typeof accounts;
  aiCopy: typeof aiCopy;
  aiCopyActions: typeof aiCopyActions;
  analytics: typeof analytics;
  campaigns: typeof campaigns;
  contacts: typeof contacts;
  inbox: typeof inbox;
  messageTemplates: typeof messageTemplates;
  users: typeof users;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
