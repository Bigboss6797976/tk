"use node";

import { v } from "convex/values";
import OpenAI from "openai";
import { action } from "./_generated/server";
import { ConvexError } from "convex/values";

const CATEGORY_PROMPTS: Record<string, string> = {
  marketing:
    "你是一位专业的 WhatsApp 营销文案专家。请根据用户需求，生成吸引人的营销推广消息。文案要简洁有力，有行动号召力（CTA），适合 WhatsApp 群发。",
  followup:
    "你是一位专业的客户跟进文案专家。请生成友好、专业的客户跟进消息，提高客户回复率和转化率。",
  greeting:
    "你是一位专业的客户问候文案专家。请生成热情、得体的问候消息，适合首次接触潜在客户或节日祝福。",
  promotion:
    "你是一位促销活动文案专家。请生成有吸引力的促销、折扣和限时优惠消息，制造紧迫感，推动下单。",
  custom:
    "你是一位专业的 WhatsApp 文案助手。请根据用户的具体要求，生成合适的消息文案。",
};

export const generateCopy = action({
  args: {
    prompt: v.string(),
    category: v.union(
      v.literal("marketing"),
      v.literal("followup"),
      v.literal("greeting"),
      v.literal("promotion"),
      v.literal("custom")
    ),
    tone: v.optional(v.string()),
    language: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ message: "请先登录", code: "UNAUTHENTICATED" });
    }
    // Limit input length to prevent AI cost abuse
    if (args.prompt.length > 1000) {
      throw new ConvexError({ message: "输入内容不能超过 1000 字符", code: "BAD_REQUEST" });
    }

    const openai = new OpenAI({
      baseURL: "http://ai-gateway.hercules.app/v1",
      apiKey: process.env.HERCULES_API_KEY,
    });

    const systemPrompt = CATEGORY_PROMPTS[args.category] ?? CATEGORY_PROMPTS.custom;
    const toneInstruction = args.tone ? `\n语气风格：${args.tone}` : "";
    const langInstruction = args.language
      ? `\n请使用${args.language}语言撰写。`
      : "\n默认使用中文撰写，除非用户有指定语言。";

    try {
      const response = await openai.chat.completions.create({
        model: "openai/gpt-5-mini",
        messages: [
          {
            role: "system",
            content: `${systemPrompt}${toneInstruction}${langInstruction}\n\n要求：\n1. 文案适合 WhatsApp 消息格式（简洁、有表情符号点缀）\n2. 生成 3 条不同风格的文案供选择\n3. 每条文案用"---"分隔\n4. 每条文案控制在 200 字以内`,
          },
          { role: "user", content: args.prompt },
        ],
      });

      const text = response.choices[0]?.message?.content ?? "";
      return { text };
    } catch (error) {
      if (error instanceof OpenAI.APIError) {
        throw new ConvexError({
          message: `AI 生成失败: ${error.message}`,
          code: "EXTERNAL_SERVICE_ERROR",
        });
      }
      throw new ConvexError({
        message: "AI 文案生成失败，请稍后重试",
        code: "EXTERNAL_SERVICE_ERROR",
      });
    }
  },
});

export const polishCopy = action({
  args: {
    text: v.string(),
    instruction: v.string(),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ message: "请先登录", code: "UNAUTHENTICATED" });
    }
    // Limit input length to prevent AI cost abuse
    if (args.text.length > 2000) {
      throw new ConvexError({ message: "文案内容不能超过 2000 字符", code: "BAD_REQUEST" });
    }
    if (args.instruction.length > 500) {
      throw new ConvexError({ message: "修改指令不能超过 500 字符", code: "BAD_REQUEST" });
    }

    const openai = new OpenAI({
      baseURL: "http://ai-gateway.hercules.app/v1",
      apiKey: process.env.HERCULES_API_KEY,
    });

    try {
      const response = await openai.chat.completions.create({
        model: "openai/gpt-5-mini",
        messages: [
          {
            role: "system",
            content:
              "你是一位 WhatsApp 消息文案润色专家。请根据用户的修改指令，对给定的文案进行润色和修改。保持 WhatsApp 消息的简洁格式。只输出润色后的文案，不要添加其他说明。",
          },
          {
            role: "user",
            content: `原文案：\n${args.text}\n\n修改要求：${args.instruction}`,
          },
        ],
      });

      const text = response.choices[0]?.message?.content ?? "";
      return { text };
    } catch (error) {
      if (error instanceof OpenAI.APIError) {
        throw new ConvexError({
          message: `AI 润色失败: ${error.message}`,
          code: "EXTERNAL_SERVICE_ERROR",
        });
      }
      throw new ConvexError({
        message: "文案润色失败，请稍后重试",
        code: "EXTERNAL_SERVICE_ERROR",
      });
    }
  },
});
