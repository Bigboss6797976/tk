import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Id } from "./_generated/dataModel.d.ts";

// List conversations with contact info, ordered by latest message
export const listConversations = query({
  args: {
    status: v.optional(v.union(v.literal("open"), v.literal("resolved"), v.literal("pending"))),
    search: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "未登录" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    let convos;
    if (args.status) {
      convos = await ctx.db
        .query("conversations")
        .withIndex("by_user_status", (q) =>
          q.eq("userId", user._id).eq("status", args.status!)
        )
        .order("desc")
        .take(100);
    } else {
      convos = await ctx.db
        .query("conversations")
        .withIndex("by_user", (q) => q.eq("userId", user._id))
        .order("desc")
        .take(100);
    }

    const results = await Promise.all(
      convos.map(async (conv) => {
        const contact = await ctx.db.get(conv.contactId);
        const account = conv.accountId ? await ctx.db.get(conv.accountId) : null;
        return { ...conv, contact, accountName: account?.name ?? null };
      })
    );

    if (args.search) {
      const q = args.search.toLowerCase();
      return results.filter(
        (r) =>
          r.contact?.name?.toLowerCase().includes(q) ||
          r.contact?.phone.includes(q) ||
          r.lastMessagePreview.toLowerCase().includes(q)
      );
    }
    return results;
  },
});

// Get messages for a conversation
export const getMessages = query({
  args: { conversationId: v.id("conversations") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "未登录" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const conv = await ctx.db.get(args.conversationId);
    if (!conv || conv.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权访问" });
    }
    return await ctx.db
      .query("inboxMessages")
      .withIndex("by_conversation_sent", (q) =>
        q.eq("conversationId", args.conversationId)
      )
      .order("asc")
      .collect();
  },
});

// Get a single conversation with contact info
export const getConversation = query({
  args: { conversationId: v.id("conversations") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) return null;

    const conv = await ctx.db.get(args.conversationId);
    if (!conv || conv.userId !== user._id) return null;
    const contact = await ctx.db.get(conv.contactId);
    const account = conv.accountId ? await ctx.db.get(conv.accountId) : null;
    return { ...conv, contact, accountName: account?.name ?? null };
  },
});

// Send a reply (outbound message)
export const sendReply = mutation({
  args: {
    conversationId: v.id("conversations"),
    content: v.string(),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "未登录" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const conv = await ctx.db.get(args.conversationId);
    if (!conv || conv.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权访问" });
    }
    const now = new Date().toISOString();
    const msgId = await ctx.db.insert("inboxMessages", {
      conversationId: args.conversationId,
      userId: user._id,
      direction: "outbound",
      content: args.content,
      status: "sent",
      sentAt: now,
    });
    await ctx.db.patch(args.conversationId, {
      lastMessageAt: now,
      lastMessagePreview: args.content.slice(0, 80),
      status: "open",
    });
    return msgId;
  },
});

// Mark conversation as read
export const markAsRead = mutation({
  args: { conversationId: v.id("conversations") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "未登录" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) return;
    const conv = await ctx.db.get(args.conversationId);
    if (!conv || conv.userId !== user._id) return;
    await ctx.db.patch(args.conversationId, { unreadCount: 0 });
  },
});

// Update conversation status
export const updateStatus = mutation({
  args: {
    conversationId: v.id("conversations"),
    status: v.union(v.literal("open"), v.literal("resolved"), v.literal("pending")),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "未登录" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });
    const conv = await ctx.db.get(args.conversationId);
    if (!conv || conv.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权访问" });
    }
    await ctx.db.patch(args.conversationId, { status: args.status });
  },
});

// Seed demo conversations for testing
export const seedDemoConversations = mutation({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "未登录" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const contacts = await ctx.db
      .query("contacts")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .take(5);

    if (contacts.length === 0) return { created: 0 };

    const now = new Date();
    let created = 0;

    for (const contact of contacts) {
      const existing = await ctx.db
        .query("conversations")
        .withIndex("by_contact", (q) => q.eq("contactId", contact._id))
        .first();
      if (existing) continue;

      const msgTime = new Date(now.getTime() - Math.random() * 86400000 * 3).toISOString();
      const samples = [
        "您好，我想了解一下你们的产品",
        "价格可以优惠吗？",
        "什么时候可以发货？",
        "收到了，谢谢！",
        "我需要更多信息",
      ];
      const preview = samples[Math.floor(Math.random() * samples.length)];
      const statusOptions: Array<"open" | "resolved"> = ["open", "resolved"];
      const status = Math.random() > 0.3 ? statusOptions[0] : statusOptions[1];

      const convId: Id<"conversations"> = await ctx.db.insert("conversations", {
        userId: user._id,
        contactId: contact._id,
        lastMessageAt: msgTime,
        lastMessagePreview: preview,
        unreadCount: Math.floor(Math.random() * 4),
        status,
      });

      const inboundTime = new Date(new Date(msgTime).getTime() - 60000).toISOString();
      await ctx.db.insert("inboxMessages", {
        conversationId: convId,
        userId: user._id,
        direction: "inbound",
        content: preview,
        status: "read",
        sentAt: inboundTime,
      });
      await ctx.db.insert("inboxMessages", {
        conversationId: convId,
        userId: user._id,
        direction: "outbound",
        content: "感谢您的消息，我们会尽快回复您！",
        status: "delivered",
        sentAt: msgTime,
      });
      created++;
    }
    return { created };
  },
});

// Get inbox stats
export const getStats = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return { total: 0, open: 0, resolved: 0, pending: 0, unread: 0 };
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) return { total: 0, open: 0, resolved: 0, pending: 0, unread: 0 };

    const allConvos = await ctx.db
      .query("conversations")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();
    return {
      total: allConvos.length,
      open: allConvos.filter((c) => c.status === "open").length,
      resolved: allConvos.filter((c) => c.status === "resolved").length,
      pending: allConvos.filter((c) => c.status === "pending").length,
      unread: allConvos.reduce((sum, c) => sum + c.unreadCount, 0),
    };
  },
});
