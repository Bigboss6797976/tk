import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";

// Get all contacts for the current user
export const list = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    return await ctx.db
      .query("contacts")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();
  },
});

// Add a single contact
export const add = mutation({
  args: {
    phone: v.string(),
    name: v.optional(v.string()),
    tags: v.array(v.string()),
    variables: v.optional(v.record(v.string(), v.string())),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    // Check duplicate
    const existing = await ctx.db
      .query("contacts")
      .withIndex("by_user_phone", (q) => q.eq("userId", user._id).eq("phone", args.phone))
      .unique();
    if (existing) {
      throw new ConvexError({ code: "CONFLICT", message: "该号码已存在" });
    }

    return await ctx.db.insert("contacts", {
      userId: user._id,
      phone: args.phone,
      name: args.name,
      tags: args.tags,
      variables: args.variables,
      source: "manual",
      createdAt: new Date().toISOString(),
    });
  },
});

// Bulk import contacts (max 5000 per request)
export const bulkImport = mutation({
  args: {
    contacts: v.array(
      v.object({
        phone: v.string(),
        name: v.optional(v.string()),
        tags: v.array(v.string()),
        variables: v.optional(v.record(v.string(), v.string())),
      })
    ),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    // Limit batch size to prevent abuse
    if (args.contacts.length > 5000) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "单次最多导入 5000 条联系人" });
    }

    let imported = 0;
    let skipped = 0;

    for (const contact of args.contacts) {
      const existing = await ctx.db
        .query("contacts")
        .withIndex("by_user_phone", (q) =>
          q.eq("userId", user._id).eq("phone", contact.phone)
        )
        .unique();

      if (existing) {
        skipped++;
        continue;
      }

      await ctx.db.insert("contacts", {
        userId: user._id,
        phone: contact.phone,
        name: contact.name,
        tags: contact.tags,
        variables: contact.variables,
        source: "import",
        createdAt: new Date().toISOString(),
      });
      imported++;
    }

    return { imported, skipped };
  },
});

// Delete a contact
export const remove = mutation({
  args: { contactId: v.id("contacts") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const contact = await ctx.db.get(args.contactId);
    if (!contact) throw new ConvexError({ code: "NOT_FOUND", message: "联系人不存在" });
    if (contact.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权删除此联系人" });
    }
    await ctx.db.delete(args.contactId);
  },
});

// Update a contact
export const update = mutation({
  args: {
    contactId: v.id("contacts"),
    name: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
    variables: v.optional(v.record(v.string(), v.string())),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const { contactId, ...updates } = args;
    const contact = await ctx.db.get(contactId);
    if (!contact) throw new ConvexError({ code: "NOT_FOUND", message: "联系人不存在" });
    if (contact.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权修改此联系人" });
    }

    const patch: Record<string, unknown> = {};
    if (updates.name !== undefined) patch.name = updates.name;
    if (updates.tags !== undefined) patch.tags = updates.tags;
    if (updates.variables !== undefined) patch.variables = updates.variables;

    await ctx.db.patch(contactId, patch);
  },
});

// Get all unique tags for the current user
export const getAllTags = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const contacts = await ctx.db
      .query("contacts")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();

    const tagSet = new Set<string>();
    for (const c of contacts) {
      for (const t of c.tags) {
        tagSet.add(t);
      }
    }
    return Array.from(tagSet).sort();
  },
});
