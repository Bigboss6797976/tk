import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    return await ctx.db
      .query("accounts")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();
  },
});

export const add = mutation({
  args: {
    name: v.string(),
    phone: v.string(),
    engine: v.union(v.literal("cloud_api"), v.literal("baileys")),
    dailySendLimit: v.number(),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    return await ctx.db.insert("accounts", {
      userId: user._id,
      name: args.name,
      phone: args.phone,
      engine: args.engine,
      status: "disconnected",
      dailySendLimit: args.dailySendLimit,
      sentToday: 0,
    });
  },
});

export const updateStatus = mutation({
  args: {
    accountId: v.id("accounts"),
    status: v.union(v.literal("connected"), v.literal("disconnected"), v.literal("warming")),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const account = await ctx.db.get(args.accountId);
    if (!account || account.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权操作此账号" });
    }
    await ctx.db.patch(args.accountId, {
      status: args.status,
      lastActiveAt: new Date().toISOString(),
    });
  },
});

export const remove = mutation({
  args: { accountId: v.id("accounts") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const account = await ctx.db.get(args.accountId);
    if (!account || account.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权删除此账号" });
    }
    await ctx.db.delete(args.accountId);
  },
});

export const updateWarmingSettings = mutation({
  args: {
    accountId: v.id("accounts"),
    warmingEnabled: v.boolean(),
    warmingDays: v.number(),
    warmingStartCount: v.number(),
    warmingIncrement: v.number(),
    sendIntervalMin: v.number(),
    sendIntervalMax: v.number(),
    sessionBreakMin: v.number(),
    sessionBreakMax: v.number(),
    batchSize: v.number(),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const { accountId, warmingEnabled, ...settings } = args;
    const account = await ctx.db.get(accountId);
    if (!account) throw new ConvexError({ code: "NOT_FOUND", message: "账号不存在" });
    if (account.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权操作此账号" });
    }

    const patch: Parameters<typeof ctx.db.patch<"accounts">>[1] = {
      ...settings,
      warmingEnabled,
    };
    // Set warmingStartedAt when warming is first enabled
    if (warmingEnabled && !account.warmingEnabled) {
      patch.warmingStartedAt = new Date().toISOString();
      patch.status = "warming";
    }
    if (!warmingEnabled && account.warmingEnabled) {
      patch.status = "connected";
    }
    await ctx.db.patch(accountId, patch);
  },
});
