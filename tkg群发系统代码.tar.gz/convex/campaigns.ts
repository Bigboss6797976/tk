import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    return await ctx.db
      .query("campaigns")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .collect();
  },
});

export const get = query({
  args: { campaignId: v.id("campaigns") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });
    const campaign = await ctx.db.get(args.campaignId);
    if (!campaign || campaign.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权访问此任务" });
    }
    return campaign;
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    content: v.string(),
    accountId: v.optional(v.id("accounts")),
    mediaUrl: v.optional(v.string()),
    targetTags: v.array(v.string()),
    scheduledAt: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const allContacts = await ctx.db
      .query("contacts")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();

    const matchingContacts =
      args.targetTags.length === 0
        ? allContacts
        : allContacts.filter((c) =>
            args.targetTags.some((tag) => c.tags.includes(tag))
          );

    const status = args.scheduledAt ? ("scheduled" as const) : ("draft" as const);

    return await ctx.db.insert("campaigns", {
      userId: user._id,
      name: args.name,
      content: args.content,
      accountId: args.accountId,
      mediaUrl: args.mediaUrl,
      status,
      scheduledAt: args.scheduledAt,
      targetTags: args.targetTags,
      totalRecipients: matchingContacts.length,
      sentCount: 0,
      deliveredCount: 0,
      readCount: 0,
      repliedCount: 0,
      failedCount: 0,
      createdAt: new Date().toISOString(),
    });
  },
});

export const updateStatus = mutation({
  args: {
    campaignId: v.id("campaigns"),
    status: v.union(
      v.literal("draft"),
      v.literal("scheduled"),
      v.literal("running"),
      v.literal("paused"),
      v.literal("completed"),
      v.literal("failed")
    ),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const campaign = await ctx.db.get(args.campaignId);
    if (!campaign || campaign.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权操作此任务" });
    }
    const patch: Record<string, unknown> = { status: args.status };
    if (args.status === "completed") {
      patch.completedAt = new Date().toISOString();
    }
    await ctx.db.patch(args.campaignId, patch);
  },
});

export const updateSchedule = mutation({
  args: {
    campaignId: v.id("campaigns"),
    scheduledAt: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const campaign = await ctx.db.get(args.campaignId);
    if (!campaign || campaign.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权操作此任务" });
    }
    await ctx.db.patch(args.campaignId, {
      scheduledAt: args.scheduledAt,
      status: args.scheduledAt ? "scheduled" : "draft",
    });
  },
});

export const duplicate = mutation({
  args: { campaignId: v.id("campaigns") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const src = await ctx.db.get(args.campaignId);
    if (!src || src.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权复制此任务" });
    }

    const now = new Date().toISOString();
    return await ctx.db.insert("campaigns", {
      userId: user._id,
      name: `${src.name}（副本）`,
      content: src.content,
      accountId: src.accountId,
      mediaUrl: src.mediaUrl,
      status: "draft",
      targetTags: src.targetTags,
      totalRecipients: src.totalRecipients,
      sentCount: 0,
      deliveredCount: 0,
      readCount: 0,
      repliedCount: 0,
      failedCount: 0,
      createdAt: now,
    });
  },
});

export const remove = mutation({
  args: { campaignId: v.id("campaigns") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const campaign = await ctx.db.get(args.campaignId);
    if (!campaign || campaign.userId !== user._id) {
      throw new ConvexError({ code: "FORBIDDEN", message: "无权删除此任务" });
    }
    await ctx.db.delete(args.campaignId);
  },
});

export const getStats = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
    }
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });

    const campaigns = await ctx.db
      .query("campaigns")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();

    const contacts = await ctx.db
      .query("contacts")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();

    const accounts = await ctx.db
      .query("accounts")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();

    const totalSent = campaigns.reduce((acc, c) => acc + c.sentCount, 0);
    const totalDelivered = campaigns.reduce((acc, c) => acc + c.deliveredCount, 0);
    const totalRead = campaigns.reduce((acc, c) => acc + c.readCount, 0);
    const totalReplied = campaigns.reduce((acc, c) => acc + c.repliedCount, 0);
    const activeCampaigns = campaigns.filter(
      (c) => c.status === "running" || c.status === "scheduled"
    ).length;

    return {
      totalContacts: contacts.length,
      totalAccounts: accounts.length,
      connectedAccounts: accounts.filter((a) => a.status === "connected").length,
      totalCampaigns: campaigns.length,
      activeCampaigns,
      totalSent,
      totalDelivered,
      totalRead,
      totalReplied,
      deliveryRate: totalSent > 0 ? Math.round((totalDelivered / totalSent) * 100) : 0,
      readRate: totalDelivered > 0 ? Math.round((totalRead / totalDelivered) * 100) : 0,
      replyRate: totalRead > 0 ? Math.round((totalReplied / totalRead) * 100) : 0,
      recentCampaigns: campaigns.slice(0, 5),
    };
  },
});
