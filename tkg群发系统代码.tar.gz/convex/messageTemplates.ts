import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { GenericQueryCtx } from "convex/server";
import type { DataModel } from "./_generated/dataModel.d.ts";

const CATEGORY_VALIDATOR = v.union(
  v.literal("marketing"),
  v.literal("followup"),
  v.literal("greeting"),
  v.literal("promotion"),
  v.literal("custom")
);

async function requireUser(ctx: GenericQueryCtx<DataModel>) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "请先登录" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) throw new ConvexError({ code: "NOT_FOUND", message: "用户不存在" });
  return user;
}

export const list = query({
  args: { category: v.optional(CATEGORY_VALIDATOR) },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    if (args.category) {
      return await ctx.db
        .query("messageTemplates")
        .withIndex("by_user_category", (q) =>
          q.eq("userId", user._id).eq("category", args.category!)
        )
        .order("desc")
        .collect();
    }
    return await ctx.db
      .query("messageTemplates")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .collect();
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    content: v.string(),
    category: CATEGORY_VALIDATOR,
    tags: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const now = new Date().toISOString();
    return await ctx.db.insert("messageTemplates", {
      userId: user._id,
      name: args.name,
      content: args.content,
      category: args.category,
      tags: args.tags,
      usageCount: 0,
      createdAt: now,
      updatedAt: now,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("messageTemplates"),
    name: v.string(),
    content: v.string(),
    category: CATEGORY_VALIDATOR,
    tags: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const tpl = await ctx.db.get(args.id);
    if (!tpl) throw new ConvexError({ code: "NOT_FOUND", message: "模板不存在" });
    if (tpl.userId !== user._id) throw new ConvexError({ code: "FORBIDDEN", message: "无权限" });
    await ctx.db.patch(args.id, {
      name: args.name,
      content: args.content,
      category: args.category,
      tags: args.tags,
      updatedAt: new Date().toISOString(),
    });
  },
});

export const remove = mutation({
  args: { id: v.id("messageTemplates") },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const tpl = await ctx.db.get(args.id);
    if (!tpl) throw new ConvexError({ code: "NOT_FOUND", message: "模板不存在" });
    if (tpl.userId !== user._id) throw new ConvexError({ code: "FORBIDDEN", message: "无权限" });
    await ctx.db.delete(args.id);
  },
});

export const incrementUsage = mutation({
  args: { id: v.id("messageTemplates") },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const tpl = await ctx.db.get(args.id);
    if (!tpl) throw new ConvexError({ code: "NOT_FOUND", message: "模板不存在" });
    if (tpl.userId !== user._id) throw new ConvexError({ code: "FORBIDDEN", message: "无权限" });
    await ctx.db.patch(args.id, { usageCount: tpl.usageCount + 1 });
  },
});
